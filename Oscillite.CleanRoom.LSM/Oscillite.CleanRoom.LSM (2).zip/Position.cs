using System;
using System.Xml.Serialization;

namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public class Position<T> where T : IComparable
	{
		protected T position;

		[XmlAttribute("V")]
		public T Value
		{
			get
			{
				return position;
			}
			set
			{
				position = value;
			}
		}

		public Position()
		{
		}

		public Position(T position)
		{
			this.position = position;
		}

		public Position(Position<T> position)
		{
			this.position = position.Value;
		}
	}
}
