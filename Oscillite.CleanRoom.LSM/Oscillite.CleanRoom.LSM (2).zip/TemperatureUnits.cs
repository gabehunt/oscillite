namespace Oscillite.CleanRoom.LSM
{
	public enum TemperatureUnits
	{
		degC,
		degF,
		xe34979bce7c9f2f5,
		x047fe104cf2ca58c
	}
}
