using System;
using System.Xml.Serialization;
using Oscillite.CleanRoom.LSM.Properties;


namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public class TriggerSource
	{
		public enum SourceType
		{
			[XmlEnum(Name = "T")]
			Trace,
			[XmlEnum(Name = "C")]
			Cylinder,
			[XmlEnum(Name = "N")]
			None
		}

		private string source;

		private SourceType type = SourceType.None;

		private string none = "None";

		private string cylinder = "Cylinder";

		[XmlAttribute("V")]
		public string Value
		{
			get
			{
				return source;
			}
			set
			{
				source = value;
			}
		}

		[XmlAttribute("ST")]
		public SourceType Type
		{
			get
			{
				return type;
			}
			set
			{
				type = value;
			}
		}

		public TriggerSource(SourceType type)
		{
			switch (type)
			{
				case SourceType.Cylinder:
					this.type = type;
					source = cylinder;
					break;
				case SourceType.None:
					this.type = type;
					source = none;
					break;
				default:
					throw new Exception("Trigger Source Type not recognized.");
			}
		}

		public TriggerSource(Trace trace)
		{
			type = SourceType.Trace;
			source = trace.Id.ToString();
		}

		public TriggerSource(TriggerSource source)
		{
			type = source.type;
			switch (source.Type)
			{
			case SourceType.Trace:
				this.source = GetTriggerSource(source.source);
				break;
			case SourceType.Cylinder:
				this.source = cylinder;
				break;
			case SourceType.None:
				this.source = none;
				break;
			default:
				throw new Exception("Trigger Source Type not recognized.");
			}
		}

		public bool IsCylinder()
		{
			return type == SourceType.Cylinder;
		}

		protected string GetTriggerSource(string trace)
		{
			if (trace.IndexOf(' ') < 0)
			{
				throw new Exception("Trigger Source Type not recognized.");
			}
			return new TraceId(Convert.ToInt32(trace.Split(' ')[1])).ToString();
		}
	}
}
