using System;
using System.Collections.Generic;

namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public class SweepList : List<Sweep>
	{
		private Sweep defaultSweep;

		private int maxNumberOfPeakDetects = 4;

		private int maxNumberOfFilters = 4;

		public Sweep this[string name]
		{
			get
			{
				using (Enumerator enumerator = GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						Sweep current = enumerator.Current;
						if (current.Name == name)
						{
							return current;
						}
					}
				}
				return null;
			}
		}

		public Sweep this[double seconds]
		{
			get
			{
				using (Enumerator enumerator = GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						Sweep current = enumerator.Current;
						if (current.Seconds == seconds)
						{
							return current;
						}
					}
				}
				return null;
			}
		}

		public Sweep this[SweepType type]
		{
			get
			{
				using (Enumerator enumerator = GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						Sweep current = enumerator.Current;
						if (current.Type == type)
						{
							return current;
						}
					}
				}
				return null;
			}
		}

		public new Sweep this[int index]
		{
			get
			{
				return base[index];
			}
			set
			{
				base[index] = value;
			}
		}

		public Sweep DefaultSweep
		{
			get
			{
				return defaultSweep;
			}
			set
			{
				defaultSweep = value;
			}
		}

		public int MaxNumberOfPeakDetects
		{
			get
			{
				return maxNumberOfPeakDetects;
			}
			set
			{
				maxNumberOfPeakDetects = value;
			}
		}

		public int MaxNumberOfFilters
		{
			get
			{
				return maxNumberOfFilters;
			}
			set
			{
				maxNumberOfFilters = value;
			}
		}

	}
}
