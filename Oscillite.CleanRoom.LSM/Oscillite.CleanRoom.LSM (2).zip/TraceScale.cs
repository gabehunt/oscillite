using System;
using System.Xml.Serialization;
using Oscillite.CleanRoom.LSM.Properties;


namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public class TraceScale
	{
		public enum Units
		{
			[XmlEnum(Name = "mV")]
			mV,
			[XmlEnum(Name = "V")]
			V,
			[XmlEnum(Name = "kV")]
			kV,
			[XmlEnum(Name = "psi")]
			psi,
			[XmlEnum(Name = "inHg")]
			inHg,
			[XmlEnum(Name = "mmHg")]
			mmHg,
			[XmlEnum(Name = "kPa")]
			kPa,
			[XmlEnum(Name = "MPa")]
			MPa,
			[XmlEnum(Name = "bar")]
			bar,
			[XmlEnum(Name = "kg/cm2")]
			kgcm2,
			[XmlEnum(Name = "mA")]
			mA,
			[XmlEnum(Name = "A")]
			A,
			[XmlEnum(Name = "deg")]
			Degree,
			[XmlEnum(Name = "ms")]
			ms,
			[XmlEnum(Name = "s")]
			s,
			[XmlEnum(Name = "%")]
			Percent,
			[XmlEnum(Name = "Hz")]
			Hz,
			[XmlEnum(Name = "kHz")]
			kHz,
			[XmlEnum(Name = "Ohms")]
			Ohms,
			[XmlEnum(Name = "kOhms")]
			kOhms,
			[XmlEnum(Name = "MOhms")]
			MOhms,
			[XmlEnum(Name = "nF")]
			nF,
			[XmlEnum(Name = "uF")]
			uF,
			[XmlEnum(Name = "mF")]
			mF,
			[XmlEnum(Name = "degF")]
			degF,
			[XmlEnum(Name = "degC")]
			degC
		}

		private string name;

		private double fullScaleValue;

		private Units units;

		private float probeGain;

		private float unitsGain;


		[XmlAttribute("N")]
		public string Name
		{
			get
			{
				return name;
			}
			set
			{
				name = value;
			}
		}

		[XmlAttribute("FSV")]
		public double FullScaleValue
		{
			get
			{
				return fullScaleValue;
			}
			set
			{
				fullScaleValue = value;
			}
		}

        public string UnitString
        {
            get
            {
                switch (units)
                {
                    case Units.mV: return "Millivolts"; // Placeholder for Resources.TraceScaleMillivolts
                    case Units.V: return "Volts"; // Placeholder for Resources.TraceScaleVolts
                    case Units.kV: return "Kilovolts"; // Placeholder for Resources.TraceScaleKilovolts
                    case Units.psi: return "Psi"; // Placeholder for Resources.TraceScalePsi
                    case Units.inHg: return "InHg"; // Placeholder for Resources.TraceScaleInHg
                    case Units.mmHg: return "MmHg"; // Placeholder for Resources.TraceScaleMmHg
                    case Units.kPa: return "Kilopascal"; // Placeholder for Resources.TraceScaleKilopascal
                    case Units.MPa: return "Megapascal"; // Placeholder for Resources.TraceScaleMegapascal
                    case Units.bar: return "Bar"; // Placeholder for Resources.TraceScaleBar
                    case Units.kgcm2: return "Kg/cm�"; // Placeholder for Resources.TraceScaleKgPerCm2
                    case Units.mA: return "Milliamps"; // Placeholder for Resources.TraceScaleMilliamps
                    case Units.A: return "Amps"; // Placeholder for Resources.TraceScaleAmps
                    case Units.Degree: return "Degree"; // Placeholder for Resources.TraceScaleDegree
                    case Units.ms: return "Milliseconds"; // Placeholder for Resources.TraceScaleMillisecond
                    case Units.s: return "Seconds"; // Placeholder for Resources.TraceScaleSecond
                    case Units.Percent: return "Percent"; // Placeholder for Resources.TraceScalePercent
                    case Units.Hz: return "Hertz"; // Placeholder for Resources.TraceScaleHertz
                    case Units.kHz: return "Kilohertz"; // Placeholder for Resources.TraceScaleKilohertz
                    case Units.Ohms: return "Ohms"; // Placeholder for Resources.TraceScaleOhms
                    case Units.kOhms: return "KiloOhms"; // Placeholder for Resources.TraceScaleKiloOhms
                    case Units.MOhms: return "MegaOhms"; // Placeholder for Resources.TraceScaleMegaOhms
                    case Units.nF: return "Nanofarad"; // Placeholder for Resources.TraceScaleNanofarad
                    case Units.uF: return "Microfarad"; // Placeholder for Resources.TraceScaleMicrofarad
                    case Units.mF: return "Millifarad"; // Placeholder for Resources.TraceScaleMillifarad
                    case Units.degF: return "Degree Fahrenheit"; // Placeholder for Resources.TraceScaleDegreeF
                    case Units.degC: return "Degree Celsius"; // Placeholder for Resources.TraceScaleDegreeC
                    default: throw new Exception("Scale has invalid Display Unit");
                }
            }
        }

		[XmlAttribute("U")]
		public Units Unit
		{
			get
			{
				return units;
			}
			set
			{
				units = value;
			}
		}

		[XmlAttribute("PG")]
		public float ProbeGain
		{
			get
			{
				return probeGain;
			}
			set
			{
				probeGain = value;
			}
		}

		public TraceScale()
		{
		}

		public TraceScale(double fullScaleValue, Units units, float probeGain, float probeOffset)
		{
			this.fullScaleValue = fullScaleValue;
			this.units = units;
			this.probeGain = probeGain;
			unitsGain = 1f;
			if (probeGain >= 10f)
			{
				float num = probeGain;
				while (num >= 10f)
				{
					num /= 10f;
				}
			}
			else if (probeGain < 0f)
			{
				float num2 = probeGain;
				while (num2 < 0f)
				{
					num2 *= 10f;
				}
			}
			switch (this.units)
			{
			case Units.mV:
                    unitsGain = 1000f;
				break;
			case Units.kV:
                    unitsGain = 0.001f;
				break;
			case Units.MPa:
                    unitsGain = 0.001f;
				break;
			case Units.mA:
                    unitsGain = 1000f;
				break;
			case Units.ms:
                    unitsGain = 1000f;
				break;
			case Units.kHz:
                    unitsGain = 0.001f;
				break;
			case Units.kOhms:
                    unitsGain = 0.001f;
				break;
			case Units.MOhms:
                    unitsGain = 1E-06f;
				break;
			case Units.nF:
                    unitsGain = 1E+09f;
				break;
			case Units.uF:
                    unitsGain = 1000000f;
				break;
			case Units.mF:
                    unitsGain = 1000f;
				break;
			default:
				throw new Exception("Scale has invalid display unit");
			case Units.V:
			case Units.psi:
			case Units.inHg:
			case Units.mmHg:
			case Units.kPa:
			case Units.bar:
			case Units.kgcm2:
			case Units.A:
			case Units.Degree:
			case Units.s:
			case Units.Percent:
			case Units.Hz:
			case Units.Ohms:
			case Units.degF:
			case Units.degC:
				break;
			}
			name = CreateScaleName(fullScaleValue, 0);
		}

		protected string CreateScaleName(double fullScaleValue, int precision)
		{
			string text = "f" + precision;
			fullScaleValue *= (double)unitsGain;
			return fullScaleValue.ToString(text) + " " + UnitString;
		}

	}
}
