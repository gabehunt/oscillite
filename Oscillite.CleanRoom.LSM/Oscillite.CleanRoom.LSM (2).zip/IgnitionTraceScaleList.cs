using System;

namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public class IgnitionTraceScaleList : TraceScaleList
	{
		public IgnitionTraceScaleList(float probeGain, float probeOffset)
			: base(TraceProbeType.TRACE_PROBE_IGNITION, hasAutoScale: false)
		{
			Add(new TraceScale(2000.0, TraceScale.Units.kV, probeGain, probeOffset));
			Add(new TraceScale(3000.0, TraceScale.Units.kV, probeGain, probeOffset));
			Add(new TraceScale(5000.0, TraceScale.Units.kV, probeGain, probeOffset));
			Add(new TraceScale(10000.0, TraceScale.Units.kV, probeGain, probeOffset));
			Add(new TraceScale(15000.0, TraceScale.Units.kV, probeGain, probeOffset));
			Add(new TraceScale(20000.0, TraceScale.Units.kV, probeGain, probeOffset));
			Add(new TraceScale(30000.0, TraceScale.Units.kV, probeGain, probeOffset));
			Add(new TraceScale(50000.0, TraceScale.Units.kV, probeGain, probeOffset));
			base.SelectedScale = base[base.Count - 1];
		}
	}
}
