using System;
using System.Xml.Serialization;

namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public class ConfigurationSettings
	{
		private BufferPosition currentBufferPosition;

		private BufferPosition frameSize;

        private ScopeSettings scopeSettings;
        
		private WaveformBufferList waveformData;

		[XmlElement("CurrentBufferPosition")]
		public BufferPosition CurrentBufferPosition
		{
			get
			{
				return currentBufferPosition;
			}
			set
			{
				currentBufferPosition = value;
			}
		}

        [XmlElement("FrameSize")]
        public BufferPosition FrameSize
        {
            get
            {
                return frameSize;
            }
            set
            {
                frameSize = value;
            }
        }

        [XmlElement("ScopeSettings")]
        public ScopeSettings ScopeSettings
        {
            get
            {
                return scopeSettings;
            }
            set
            {
                scopeSettings = value;
            }
        }

		[XmlArray("WaveformDataList")]
		[XmlArrayItem("WaveformData")]
		public WaveformBufferList WaveformData
		{
			get
			{
				return waveformData;
			}
			set
			{
				waveformData = value;
			}
		}
	}
}
