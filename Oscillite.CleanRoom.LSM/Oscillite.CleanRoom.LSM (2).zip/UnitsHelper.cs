﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Oscillite.CleanRoom.LSM.Properties;

namespace Oscillite.CleanRoom.LSM
{
    public static class UnitsHelper
    {
        private const double SECONDS_PER_HOUR = 3600.0;
        private const double SECONDS_PER_MINUTE = 60.0;
        private const double SECONDS_PER_SECOND = 1.0;
        private const double SECONDS_PER_MILLISECOND = 0.001;
        private const double MILLISECONDS_PER_SECOND = 1000.0;
        private const double MICROSECONDS_PER_SECOND = 1000000.0;

        // We ran into cases where the unit gain needed to be calculated based on time
        public static void GetUnitsFromSeconds(double seconds, out string unit, out double gain)
        {
            if (seconds >= SECONDS_PER_HOUR && seconds % SECONDS_PER_HOUR == 0.0)
            {
                unit = SweepLabels.SweepHours;
                gain = 1.0 / SECONDS_PER_HOUR;
            }
            else if (seconds >= SECONDS_PER_MINUTE && seconds % SECONDS_PER_MINUTE == 0.0)
            {
                unit = SweepLabels.SweepMinutes;
                gain = 1.0 / SECONDS_PER_MINUTE;
            }
            else if (seconds >= SECONDS_PER_SECOND)
            {
                unit = SweepLabels.SweepSeconds;
                gain = 1.0; // This appears to be the base so make it 1.0
            }
            else if (seconds >= SECONDS_PER_MILLISECOND)
            {
                unit = SweepLabels.SweepMilliseconds;
                gain = MILLISECONDS_PER_SECOND;
            }
            else
            {
                unit = SweepLabels.SweepMicroseconds;
                gain = MICROSECONDS_PER_SECOND;
            }
        }
    }

}
