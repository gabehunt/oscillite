using System;

namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public class CursorPosition : Position<double>
	{
	}
}
