namespace Oscillite.CleanRoom.LSM
{
	public enum VacuumUnits
	{
		inHg,
		kPa,
		mmHg
	}
}
