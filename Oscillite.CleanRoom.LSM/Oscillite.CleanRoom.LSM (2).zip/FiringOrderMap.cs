﻿using System.Collections.Generic;

namespace Oscillite.CleanRoom.LSM
{
    /// <summary>
    /// Known firing orders found in LSM file headers. 
    /// Indexed by ID as found in header field. 
    /// This list is not exhaustive.
    /// </summary>
    public static class FiringOrderMap
    {
        public static Dictionary<int, string> GetDefaultFiringOrders()
        {
            return new Dictionary<int, string>
            {
                // 1 Cylinder
                { 48, "1" },

                // 2 Cylinder
                { 1, "1 2" },

                // 3 Cylinder
                { 2, "1 2 3" },
                { 30, "1 3 2" },
                
                // Inline-4 Variants
                { 3, "1 3 4 2" },
                { 4, "1 3 2 4" },
                { 5, "1 4 3 2" },
                { 6, "1 2 4 3" },
                { 26, "1 2 3 4" },

                // Inline-5
                { 7, "1 2 4 5 3" },
                { 27, "1 2 3 4 5" },
                { 41, "1 2 3 5 4" },

                // Inline-6 and Common V6
                { 8, "1 5 3 6 2 4" },
                { 9, "1 2 3 4 5 6" },
                { 10, "1 4 2 5 3 6" },
                { 11, "1 6 5 4 3 2" },
                { 12, "1 6 3 5 2 4" },
                { 13, "1 6 2 4 3 5" },
                { 14, "1 4 5 2 3 6" },
                { 33, "1 6 3 2 5 4" },
                { 39, "1 4 3 6 2 5" },
                { 42, "1 6 2 5 3 4" },

                // V8 Variants
                { 15, "1 8 4 3 6 5 7 2" },
                { 16, "1 5 6 3 4 2 7 8" },
                { 17, "1 5 4 2 6 3 7 8" },
                { 18, "1 3 7 2 6 5 4 8" },
                { 19, "1 5 4 8 6 3 7 2" },
                { 20, "1 6 2 5 8 3 7 4" },
                { 21, "1 2 7 8 4 5 6 3" },
                { 22, "1 8 7 2 6 5 4 3" },
                { 23, "1 8 7 3 6 5 4 2" },
                { 25, "8 4 3 6 5 7 2 1" },
                { 28, "1 2 3 4 5 6 7 8" },
                { 29, "1 2 7 3 4 5 6 8" }, // found this with two ids
                { 35, "1 8 4 2 6 3 7 5" },
                { 38, "1 2 7 3 4 5 6 8" }, // found this with two ids
                { 47, "1 5 3 7 4 8 2 6" },
                
                // V10 / V12
                { 45, "1 2 3 4 5 6 7 8 9 10" },
                { 40, "1 10 9 4 3 6 5 8 7 2" },
                { 34, "1 7 5 11 3 9 6 12 2 8 4 10" },
                { 43, "1 12 5 8 3 10 6 7 2 11 4 9" },
                { 44, "1 6 5 10 2 7 3 8 4 9" },
                { 46, "1 9 5 12 3 8 6 10 2 7 4 11" },
                { 31, "1 2 3 4 5 6 7 8 9 10 11 12" },
                { 0, "1 2 3 4 5 6 7 8 9 10 11 12" },

                // Waste spark
                { 24, "1A 6B 5A 2B 3A 4B 6A 1B 2A 5B 4A 3B" },
                { 32, "1A 2A 1B 2B 1C 2C" }, //only found in 1 binary file
                { 36, "A1 B1 A4 B4 B2 A3 B3 A2" },
                { 37, "1A 1B 2A 2B 3A 3B" },

            };
        }
    }
}
