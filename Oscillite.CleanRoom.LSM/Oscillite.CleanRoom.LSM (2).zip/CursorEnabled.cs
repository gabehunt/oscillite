using System;
using System.Xml.Serialization;

namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public class CursorEnabled
	{
		private bool cursorEnabled;

		[XmlAttribute("V")]
		public bool Value
		{
			get
			{
				return cursorEnabled;
			}
			set
			{
				cursorEnabled = value;
			}
		}
	}
}
