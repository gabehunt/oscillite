using System;
using System.Xml.Serialization;

namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public class TracePeakDetect
	{
		public enum PeakDetectStatus
		{
			[XmlEnum(Name = "On")]
			On,
			[XmlEnum(Name = "D")]
			Disabled,
			[XmlEnum(Name = "Off")]
			Off
		}

		private PeakDetectStatus status = PeakDetectStatus.Off;

		[XmlAttribute("V")]
		public PeakDetectStatus Value
		{
			get
			{
				return status;
			}
			set
			{
				status = value;
			}
		}

		public TracePeakDetect()
		{
			status = PeakDetectStatus.Off;
		}
	}
}
