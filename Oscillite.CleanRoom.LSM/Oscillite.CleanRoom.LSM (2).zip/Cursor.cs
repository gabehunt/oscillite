using System;
using System.Xml.Serialization;

namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public class Cursor
	{
		private CursorId cursorId;

		private CursorEnabled cursorEnabled;

		private CursorPosition cursorPosition;

		[XmlElement("Id")]
		public CursorId Id
		{
			get
			{
				return cursorId;
			}
			set
			{
				cursorId = value;
			}
		}

		[XmlElement("E")]
		public CursorEnabled Enabled
		{
			get
			{
				return cursorEnabled;
			}
			set
			{
				cursorEnabled = value;
			}
		}

		[XmlElement("P")]
		public CursorPosition Position
		{
			get
			{
				return cursorPosition;
			}
			set
			{
				cursorPosition = value;
			}
		}
	}
}
