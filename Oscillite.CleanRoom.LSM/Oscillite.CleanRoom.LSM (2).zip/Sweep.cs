using System;
using System.Xml.Serialization;
using Oscillite.CleanRoom.LSM.Properties;

namespace Oscillite.CleanRoom.LSM
{
    [Serializable]
    public class Sweep
    {
        private double seconds = 20;
        private SweepType type = SweepType.Time;

        [XmlIgnore]
        private string Unit { get; set; } = "sec";

        [XmlIgnore]
        private double Gain { get; set; } = 1.0;

        [XmlAttribute("N")]
        public string Name => $"{(Seconds * Gain)} {Unit}";

        [XmlAttribute("Sec")]
        public double Seconds
        {
            get
            {
                return seconds;
            }
            set
            {
                seconds = value;
                UnitsHelper.GetUnitsFromSeconds(value, out string unit, out double gain);
                Unit = unit;
                Gain = gain;
            }
        }

        [XmlAttribute("T")]
        public SweepType Type { get { return type; } set { type = value; } }

    }
}