using System;
using System.Collections.Generic;

namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public class TraceScaleList : List<TraceScale>
	{
		private TraceScale m_selectedScale;

		private bool m_hasAutoScale;

		public TraceScale SelectedScale
		{
			get
			{
				return m_selectedScale;
			}
			set
			{
				m_selectedScale = value;
			}
		}

		public bool HasAutoScale
		{
			get
			{
				return m_hasAutoScale;
			}
			set
			{
				m_hasAutoScale = value;
			}
		}

		public TraceScale this[string name]
		{
			get
			{
				using (Enumerator enumerator = GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						TraceScale current = enumerator.Current;
						if (current.Name == name)
						{
							return current;
						}
					}
				}
				return null;
			}
		}

		public TraceScale this[double fullScaleValue]
		{
			get
			{
				using (Enumerator enumerator = GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						TraceScale current = enumerator.Current;
						if (current.FullScaleValue == fullScaleValue)
						{
							return current;
						}
					}
				}
				return null;
			}
		}

		public new TraceScale this[int index]
		{
			get
			{
				return base[index];
			}
			set
			{
				base[index] = value;
			}
		}

		protected TraceScaleList(TraceProbeType probeType, bool hasAutoScale)
		{
			m_selectedScale = null;
			m_hasAutoScale = hasAutoScale;
		}
	}
}
