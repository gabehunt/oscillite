using System;
using System.Xml.Serialization;

namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public class ThresholdValue
	{
		private float value;

		[XmlAttribute("V")]
		public float Value
		{
			get
			{
				return value;
			}
			set
			{
				this.value = value;
			}
		}

	}
}
