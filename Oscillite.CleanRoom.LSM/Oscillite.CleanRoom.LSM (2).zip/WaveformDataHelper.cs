using System;
using System.IO;

namespace Oscillite.CleanRoom.LSM
{
	public class WaveformDataHelper
	{
        private WaveformHeader[] waveformHeader;

        private const int MILLION_DIVISOR = 1000000;

        private const int NUMBER_OF_CHANNELS = 4;

        private const int ENCODING_NULL_BYTE_COUNT = 2;
        
		private const ushort V1_0_SWEEP_LENGTH = 600;

        //Sweep Length (width) appears to have been reduced after v1.0
        private const ushort V1_1_SWEEP_LENGTH = 560;

		private ConfigurationSettingsLoader lsmFileReader;

		public WaveformDataHelper(ConfigurationSettingsLoader lsmFR)
		{
			waveformHeader = new WaveformHeader[NUMBER_OF_CHANNELS];
			lsmFileReader = lsmFR;
		}

		public void ReadFrameFromVersion(BinaryReader binaryReader, FileVersion? fileVersion, string fileExt)
		{
			int i = 0;
			int outputIndex = 0;
			int headerIndex = 0;
			int numberOfPoints = 0;
			ushort[][] array = new ushort[NUMBER_OF_CHANNELS][];
			WaveformBufferList bufferList = new WaveformBufferList();
			if (fileVersion == FileVersion.V1_0 || fileVersion == FileVersion.V1_1 || fileVersion == FileVersion.V1_2)
			{
				ushort defaultSweepWithForFileVersion = 0;
				if (fileVersion == FileVersion.V1_0)
				{
					for (headerIndex = 0; headerIndex < 4; headerIndex++)
					{
						waveformHeader[headerIndex].calibrationMultiplier = binaryReader.ReadInt32();
						waveformHeader[headerIndex].calibrationDivisor = binaryReader.ReadInt32();
						waveformHeader[headerIndex].calibrationOffset = binaryReader.ReadInt32();
						waveformHeader[headerIndex].numberOfPoints = binaryReader.ReadInt32();
					}
				}
				else
				{
					for (headerIndex = 0; headerIndex < 4; headerIndex++)
					{
						waveformHeader[headerIndex].averageValue = binaryReader.ReadDouble();
						waveformHeader[headerIndex].minValue = binaryReader.ReadDouble();
						waveformHeader[headerIndex].maxValue = binaryReader.ReadDouble();
					}
					for (headerIndex = 0; headerIndex < 4; headerIndex++)
					{
						waveformHeader[headerIndex].calibrationMultiplier = binaryReader.ReadInt32();
						waveformHeader[headerIndex].calibrationDivisor = binaryReader.ReadInt32();
						waveformHeader[headerIndex].calibrationOffset = binaryReader.ReadInt32();
						waveformHeader[headerIndex].numberOfPoints = binaryReader.ReadInt32();
					}
				}
				for (headerIndex = 0; headerIndex < 4; headerIndex++)
				{
					if (waveformHeader[headerIndex].numberOfPoints > 0)
					{
						numberOfPoints = waveformHeader[headerIndex].numberOfPoints;
						array[headerIndex] = new ushort[numberOfPoints];
                        FillWithMaxValue(array[headerIndex]);
					}
				}
				defaultSweepWithForFileVersion = (ushort)((fileVersion == FileVersion.V1_0) ? V1_0_SWEEP_LENGTH : ((fileVersion != FileVersion.V1_1) ? ((ushort)lsmFileReader.SweepWidth) : V1_1_SWEEP_LENGTH));
				ushort sweepWidth = SweepWidthHelper.GetSweepWidth(lsmFileReader.ConfigurationSettings.ScopeSettings.Sweep);
				if (defaultSweepWithForFileVersion == sweepWidth)
				{
					for (i = 0; i < numberOfPoints; i++)
					{
						if (array[0] != null)
						{
							array[0][i] = (ushort)binaryReader.ReadInt16();
						}
						else
						{
							binaryReader.BaseStream.Position += 2L;
						}
						if (array[1] != null)
						{
							array[1][i] = (ushort)binaryReader.ReadInt16();
						}
						else
						{
							binaryReader.BaseStream.Position += ENCODING_NULL_BYTE_COUNT;
						}
						if (array[2] != null)
						{
							array[2][i] = (ushort)binaryReader.ReadInt16();
						}
						else
						{
							binaryReader.BaseStream.Position += ENCODING_NULL_BYTE_COUNT;
						}
						if (array[3] != null)
						{
							array[3][i] = (ushort)binaryReader.ReadInt16();
						}
						else
						{
							binaryReader.BaseStream.Position += ENCODING_NULL_BYTE_COUNT;
						}
					}
				}
				else
				{
					bool flag = true;
					int resampleBlockCount = 0;
					int resampleOffset = 0;
					int tempSweepWidth = 560;
					int inputSampleCount = numberOfPoints * NUMBER_OF_CHANNELS;
					ushort[][] dataPointTo = new ushort[tempSweepWidth][];
					ushort[][] dataPointTo2 = new ushort[tempSweepWidth][];
					ushort[][] array2 = new ushort[inputSampleCount][];
					for (i = 0; i < tempSweepWidth; i++)
					{
						dataPointTo[i] = new ushort[4];
						dataPointTo2[i] = new ushort[4];
					}
					for (i = 0; i < inputSampleCount; i++)
					{
						array2[i] = new ushort[NUMBER_OF_CHANNELS];
					}
					for (i = 0; i < inputSampleCount; i++)
					{
						for (headerIndex = 0; headerIndex < NUMBER_OF_CHANNELS; headerIndex++)
						{
							array2[i][headerIndex] = ushort.MaxValue;
						}
					}
					while (flag)
					{
						resampleBlockCount++;
						for (i = 0; i < tempSweepWidth; i++)
						{
							for (headerIndex = 0; headerIndex < NUMBER_OF_CHANNELS; headerIndex++)
							{
								dataPointTo[i][headerIndex] = ushort.MaxValue;
								dataPointTo2[i][headerIndex] = ushort.MaxValue;
							}
						}
						for (i = 0; i < tempSweepWidth; i++)
						{
							if (binaryReader.BaseStream.Position < binaryReader.BaseStream.Length)
							{
								for (headerIndex = 0; headerIndex < NUMBER_OF_CHANNELS; headerIndex++)
								{
									dataPointTo[i][headerIndex] = (ushort)binaryReader.ReadInt16();
								}
								continue;
							}
							flag = false;
							break;
						}
						ResampleWaveformData(dataPointTo, defaultSweepWithForFileVersion, dataPointTo2, sweepWidth);
						ResampleWaveformData(dataPointTo2, sweepWidth, dataPointTo, defaultSweepWithForFileVersion);
						for (i = 0; i < tempSweepWidth; i++)
						{
							for (headerIndex = 0; headerIndex < NUMBER_OF_CHANNELS; headerIndex++)
							{
								outputIndex = i + resampleOffset;
								if (array[headerIndex] != null && outputIndex < array[headerIndex].Length)
								{
									array[headerIndex][outputIndex] = dataPointTo[i][headerIndex];
								}
							}
						}
						if (i == tempSweepWidth)
						{
							resampleOffset = tempSweepWidth * resampleBlockCount;
						}
					}
				}
			}
			else
			{
				byte[][] array3 = new byte[NUMBER_OF_CHANNELS][];
				for (headerIndex = 0; headerIndex < NUMBER_OF_CHANNELS; headerIndex++)
				{
					waveformHeader[headerIndex].calibrationMultiplier = binaryReader.ReadInt32();
					waveformHeader[headerIndex].calibrationDivisor = binaryReader.ReadInt32();
					waveformHeader[headerIndex].calibrationOffset = binaryReader.ReadInt32();
					waveformHeader[headerIndex].numberOfPoints = binaryReader.ReadInt32();
					waveformHeader[headerIndex].pointSize = binaryReader.ReadInt16();
					waveformHeader[headerIndex].averageValue = binaryReader.ReadDouble();
					waveformHeader[headerIndex].minValue = binaryReader.ReadDouble();
					waveformHeader[headerIndex].maxValue = binaryReader.ReadDouble();
					binaryReader.BaseStream.Position += NUMBER_OF_CHANNELS;
					short decimationFactor = binaryReader.ReadInt16();
					if (decimationFactor == 0)
					{
						decimationFactor = 1;
					}
					switch (decimationFactor)
					{
						case 1:
						case 3:
						case 6:
						case 10:
						case 15:
							lsmFileReader.Decimation = decimationFactor;
							if (waveformHeader[headerIndex].numberOfPoints != lsmFileReader.BufferPointCount)
							{
								waveformHeader[headerIndex].numberOfPoints = 0;
							}
							if (waveformHeader[headerIndex].numberOfPoints <= 0 || waveformHeader[headerIndex].pointSize <= 0)
							{
								break;
							}
							numberOfPoints = waveformHeader[headerIndex].numberOfPoints * waveformHeader[headerIndex].pointSize;
							array3[headerIndex] = new byte[numberOfPoints];
							array3[headerIndex] = binaryReader.ReadBytes(numberOfPoints);
							array[headerIndex] = new ushort[lsmFileReader.BufferPointCount];
                            FillWithMaxValue(array[headerIndex]);
                            for (i = 0; i < array3[headerIndex].Length; i += ENCODING_NULL_BYTE_COUNT)
							{
								outputIndex = i / 2;
								if (outputIndex < array[headerIndex].Length)
								{
									array[headerIndex][outputIndex] = BitConverter.ToUInt16(array3[headerIndex], i);
								}
							}
							break;
						default:
							throw new Exception("Invalid Decimation");
					}
				}
			}
			for (headerIndex = 0; headerIndex < NUMBER_OF_CHANNELS; headerIndex++)
			{
				if (array[headerIndex] != null)
				{
                    TraceProbeType probeType = TraceProbeType.TRACE_PROBE_VOLTS;

					if (lsmFileReader.ConfigurationSettings.ScopeSettings.ScopeType == ScopeType.ScopeType_GraphingMeter)
					{
                        probeType = lsmFileReader.ConfigurationSettings.ScopeSettings.TraceList[headerIndex].Probe.Type;
					}

                    switch (probeType)
					{
                        case TraceProbeType.TRACE_PROBE_MCDWELL_60:
                        case TraceProbeType.TRACE_PROBE_MCDWELL_90:
                        case TraceProbeType.TRACE_PROBE_DUTY_CYCLE:
                            GetCalibratedValuesFromRawData(headerIndex, array[headerIndex], bufferList, fileExt, 1);
                            break;
                        case TraceProbeType.TRACE_PROBE_FREQUENCY:
                                GetFrequenciesFromRawData(headerIndex, array[headerIndex], bufferList, fileExt);
							break;
                        case TraceProbeType.TRACE_PROBE_INJECTOR_PULSE_WIDTH:
                        case TraceProbeType.TRACE_PROBE_PULSE_WIDTH:
                                GetCalibratedValuesFromRawData(headerIndex, array[headerIndex], bufferList, fileExt, MILLION_DIVISOR);
							break;
						default:
							GetDataValuesFromRaw(headerIndex, array[headerIndex], bufferList, fileExt);
							break;
					}
				}
			}
            lsmFileReader.ConfigurationSettings.WaveformData = bufferList;
            lsmFileReader.ConfigurationSettings.FrameSize = new BufferPosition(lsmFileReader.SweepWidth);
		}

        private void FillWithMaxValue(ushort[] target)
        {
            for (int i = 0; i < target.Length; i++) target[i] = ushort.MaxValue;
        }

        public void ResampleWaveformData(ushort[][] fromPoint, ushort fromLength, ushort[][] toPoint, ushort toLength)
		{
            int ushortOverflow = ushort.MaxValue + 1;
            ushort sampleRate = (ushort)((int)fromLength / (int)toLength);
			ushort remainderSpread = (ushort)((long)((int)fromLength % (int)toLength) * ushortOverflow / (long)toLength);
			long fractionalErrorAccumulator = 0L;
			ushort fromIndex = 0;
            for (ushort toIndex = 0; toIndex < toLength; toIndex = (ushort)(toIndex + 1))
			{
				for (int i = 0; i < 4; i++)
				{
					toPoint[toIndex][i] = fromPoint[fromIndex][i];
				}
				fractionalErrorAccumulator += remainderSpread;
				if (fractionalErrorAccumulator >= ushortOverflow)
				{
					fractionalErrorAccumulator -= ushortOverflow;
					fromIndex = (ushort)(fromIndex + 1);
				}
				fromIndex = (ushort)(fromIndex + sampleRate);
			}
		}

        public void GetDataValuesFromRaw(int idx, ushort[] bufferPoints, WaveformBufferList bufferList, string fileExt)
        {
            WaveformBuffer waveformBuffer = new WaveformBuffer
            {
                TraceId = new TraceId(idx + 1)
            };

            var header = waveformHeader[idx];
            bool isSFrame = ScopeFileExtensionMap.SFrameFileExtensions.Contains(fileExt.ToLower());

            if (isSFrame)
            {
                int sweepWidth = (int)lsmFileReader.SweepWidth;
                int startIndex = (int)lsmFileReader.BufferPointIndex;
                waveformBuffer.Points = new float[sweepWidth];

                for (int i = 0; i < sweepWidth; i++)
                {
                    int rawIndex = startIndex + i;

                    waveformBuffer.Points[i] = (rawIndex >= bufferPoints.Length || bufferPoints[rawIndex] == ushort.MaxValue)
                        ? float.NaN
                        : GetDataValueFromRaw(bufferPoints[rawIndex], header);
                }
            }
            else
            {
                waveformBuffer.Points = new float[bufferPoints.Length];

                for (int i = 0; i < bufferPoints.Length; i++)
                {
                    waveformBuffer.Points[i] = (bufferPoints[i] == ushort.MaxValue)
                        ? float.NaN
                        : GetDataValueFromRaw(bufferPoints[i], header);
                }
            }

            bufferList.Add(waveformBuffer);
        }

        private float GetDataValueFromRaw(ushort rawValue, WaveformHeader header)
        {
			// this was the only math that got us to the known values in the provided sample files and it seems to make sense
			return ((rawValue - header.calibrationOffset) * header.calibrationMultiplier) / (float)header.calibrationDivisor;
        }

        public void GetFrequenciesFromRawData(int idx, ushort[] bufferPoints, WaveformBufferList bufferList, string fileExt)
        {
            WaveformBuffer waveformBuffer = new WaveformBuffer
            {
                TraceId = new TraceId(idx + 1)
            };

            var header = waveformHeader[idx];
            bool isSFrame = ScopeFileExtensionMap.SFrameFileExtensions.Contains(fileExt.ToLower());

            if (isSFrame)
            {
                int sweepWidth = (int)lsmFileReader.SweepWidth;
                int startIndex = (int)lsmFileReader.BufferPointIndex;
                waveformBuffer.Points = new float[sweepWidth];

                for (int i = 0; i < sweepWidth; i++)
                {
                    int rawIndex = startIndex + i;

                    waveformBuffer.Points[i] = (rawIndex >= bufferPoints.Length || bufferPoints[rawIndex] == ushort.MaxValue)
                        ? float.NaN
                        : FrequencyFromRaw(bufferPoints[rawIndex], header);
                }
            }
            else
            {
                waveformBuffer.Points = new float[bufferPoints.Length];

                for (int i = 0; i < bufferPoints.Length; i++)
                {
                    waveformBuffer.Points[i] = (bufferPoints[i] == ushort.MaxValue)
                        ? float.NaN
                        : FrequencyFromRaw(bufferPoints[i], header);
                }
            }

            bufferList.Add(waveformBuffer);
        }

        private float FrequencyFromRaw(ushort rawValue, WaveformHeader header)
        {
            float calibrated = ((rawValue - header.calibrationOffset) * header.calibrationMultiplier) / (float)header.calibrationDivisor;
            float microseconds = calibrated / MILLION_DIVISOR;

            return 1f / microseconds;
        }

        public void GetCalibratedValuesFromRawData(int idx, ushort[] bufferPoints, WaveformBufferList bufferList, string fileExt, int additionalDivisor)
        {
            WaveformBuffer waveformBuffer = new WaveformBuffer
            {
                TraceId = new TraceId(idx + 1)
            };

            var header = waveformHeader[idx];
            bool isSFrame = ScopeFileExtensionMap.SFrameFileExtensions.Contains(fileExt.ToLower());

            if (isSFrame)
            {
                int sweepWidth = (int)lsmFileReader.SweepWidth;
                int startIndex = (int)lsmFileReader.BufferPointIndex;
                waveformBuffer.Points = new float[sweepWidth];

                for (int i = 0; i < sweepWidth; i++)
                {
                    int rawIndex = startIndex + i;

                    waveformBuffer.Points[i] = (rawIndex >= bufferPoints.Length || bufferPoints[rawIndex] == ushort.MaxValue)
                        ? float.NaN
                        : GetCalibratedValue(bufferPoints[rawIndex], header, additionalDivisor);
                }
            }
            else
            {
                waveformBuffer.Points = new float[bufferPoints.Length];

                for (int i = 0; i < bufferPoints.Length; i++)
                {
                    waveformBuffer.Points[i] = (bufferPoints[i] == ushort.MaxValue)
                        ? float.NaN
                        : GetCalibratedValue(bufferPoints[i], header, additionalDivisor);
                }
            }

            bufferList.Add(waveformBuffer);
        }

        private float GetCalibratedValue(ushort raw, WaveformHeader header, int additionalDivisor)
        {
            float calibrated = ((raw - header.calibrationOffset) * header.calibrationMultiplier) / (float)header.calibrationDivisor;
            return calibrated / additionalDivisor;
        }
	}
}
