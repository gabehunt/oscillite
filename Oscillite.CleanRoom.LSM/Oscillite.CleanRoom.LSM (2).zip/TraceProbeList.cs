using System;
using System.Collections.Generic;

namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
    public class TraceProbeList : List<TraceProbe>
    {
        public TraceProbe this[string name]
        {
            get
            {
                using (var enumerator = GetEnumerator())
                {
                    while (enumerator.MoveNext())
                    {
                        TraceProbe current = enumerator.Current;
                        if (current.Name == name)
                        {
                            return current;
                        }
                    }
                }
                return null;
            }
        }

        public TraceProbe this[TraceProbeType type]
        {
            get
            {
                using (var enumerator = GetEnumerator())
                {
                    while (enumerator.MoveNext())
                    {
                        TraceProbe current = enumerator.Current;
                        if (current.Type == type)
                        {
                            return current;
                        }
                    }
                }
                return null;
            }
        }

    }
}
