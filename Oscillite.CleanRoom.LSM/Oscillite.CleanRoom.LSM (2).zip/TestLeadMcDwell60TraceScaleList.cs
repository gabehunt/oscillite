using System;

namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public class TestLeadMcDwell60TraceScaleList : TraceScaleList
	{
		public TestLeadMcDwell60TraceScaleList(float probeGain, float probeOffset)
			: base(TraceProbeType.TRACE_PROBE_MCDWELL_60, hasAutoScale: false)
		{
			Add(new TraceScale(20.0, TraceScale.Units.Degree, probeGain, probeOffset));
			Add(new TraceScale(40.0, TraceScale.Units.Degree, probeGain, probeOffset));
			Add(new TraceScale(60.0, TraceScale.Units.Degree, probeGain, probeOffset));
			base.SelectedScale = base[base.Count - 1];
		}
	}
}
