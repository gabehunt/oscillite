using System;
using System.Collections.Generic;

namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public class TraceList : List<Trace>
	{
		public enum TraceCount
		{
			One = 1,
			Two = 2,
			Four = 4
		}

		public Trace this[TraceId id]
		{
			get
			{
				for (int i = 0; i < base.Count; i++)
				{
					if (this[i].Id.Value == id.Value)
					{
						return this[i];
					}
				}
				throw new Exception("Trace " + id.ToString() + " not found");
			}
		}

		public new Trace this[int index]
		{
			get
			{
				return base[index];
			}
			set
			{
				base[index] = value;
			}
		}

		public TraceList(ScopeType scopeType, TraceCount traceCount, TraceProbeList probes)
		{
			for (int i = 0; i < (int)traceCount; i++)
			{
				Trace trace = new Trace();

                trace.Id = new TraceId(i + 1);
				trace.Probe = scopeType == ScopeType.ScopeType_IgnitionScope ? probes[TraceProbeType.TRACE_PROBE_IGNITION] : probes[TraceProbeType.TRACE_PROBE_VOLTS];
                trace.Scale = trace.Probe.TraceScaleList.SelectedScale;
                trace.Position = new TracePosition(trace.Scale.FullScaleValue / 10.0);
                trace.RasterSpacing = new TraceRasterSpacing(trace.Scale.FullScaleValue / 20.0);
                if (trace.Probe.IsCalculatedProbe())
                {
                    if (trace.Probe.Type == TraceProbeType.TRACE_PROBE_INJECTOR_PULSE_WIDTH)
                    {
                        trace.ThresholdSlope = new ThresholdSlope();
                    }
                    else
                    {
                        trace.ThresholdSlope = new ThresholdSlope();
                    }
                }
                else
                {
                    trace.ThresholdSlope = new ThresholdSlope();
                }

                switch (scopeType)
                {
                    case ScopeType.ScopeType_GraphingMeter:
                        trace.PeakDetect.Value = TracePeakDetect.PeakDetectStatus.On;
                        trace.Filter.Value = FilterState.On;
                        break;
                    case ScopeType.ScopeType_IgnitionScope:
                        trace.Inverted.Value = true;
                        trace.PeakDetect.Value = TracePeakDetect.PeakDetectStatus.On;
                        break;
                }

                Add(trace);
			}
		}

	}
}
