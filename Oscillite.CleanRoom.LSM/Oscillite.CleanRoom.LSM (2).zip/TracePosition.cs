using System;

namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public class TracePosition : Position<double>
	{
		public TracePosition()
			: base(0.0)
		{
		}

		public TracePosition(double position)
			: base(position)
		{
		}
	}
}
