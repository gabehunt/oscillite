using System;
using System.Xml.Serialization;

namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public class WaveformBuffer
	{
		private TraceId traceId;

		private float[] points;

		[XmlElement("TId")]
		public TraceId TraceId
		{
			get
			{
				return traceId;
			}
			set
			{
				traceId = value;
			}
		}

		[XmlArray("PL")]
		[XmlArrayItem("P")]
		public float[] Points
		{
			get
			{
				return points;
			}
			set
			{
				if (value != null)
				{
					points = value;
				}
			}
		}

		public WaveformBuffer()
		{
		}
	}
}
