using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Oscillite.CleanRoom.LSM
{
	public class ConfigurationSettingsLoader
	{
		private const int NUMBER_OF_TRACES = 4;

		private const int NUMBER_OF_CHANNELS = 4;

		private const int NUMBER_OF_TRIGGERS = 6;

		private const int NUMBER_OF_CURSORS = 2;

		private const int LSM_HEADER_LENGTH = 3020;

		private const int DEFAULT_SWEEP_SETTING_COUNT = 24;

		private const int DEFAULT_UNIT_ADJUSTMENT_FACTOR = 1000;

		private const ushort EXTENDED_SWEEP_WIDTH = 600;

		private const ushort DEFAULT_SWEEP_WIDTH = 560;

        private const string LSM_MAGIC = "MDLS"; //this was the first 4 bytes of all files tested

		private Dictionary<int, string> allTraceScales;

		private Dictionary<int, TraceProbeType> allTraceProbeTypes;

		private Dictionary<int, string> allFiringOrders;

		private Dictionary<int, object> allSweepTimes;

		private ConfigurationSettings configurationSettings;

		private ASCIIEncoding asciiEncoding = new ASCIIEncoding();

		private string fieldValueString = string.Empty;

		private int fieldValueInt;

		private double fieldValueDouble;

		private Stream stream;

		private string header = string.Empty;

		private string[] scale;

		private double[] position;

		private float[] unitsGain;

		private uint bufferPointIndex;

		private uint bufferPointCount;

		private uint sweepWidth;

		private VacuumUnits[] vacuumUnits;

		private PressureUnits[] pressureUnits;

		private TemperatureUnits[] temperatureUnits;

		private BinaryReader binaryReader;

		private WaveformDataHelper waveformDataHelper;

		public string Header => header;

		public ConfigurationSettings ConfigurationSettings => configurationSettings;

		public uint BufferPointIndex
		{
			get
			{
				return bufferPointIndex;
			}
			set
			{
				bufferPointIndex = value;
			}
		}

		public uint BufferPointCount
		{
			get
			{
				return bufferPointCount;
			}
			set
			{
				bufferPointCount = value;
			}
		}

		public uint SweepWidth
		{
			get
			{
				return sweepWidth;
			}
			set
			{
				sweepWidth = value;
			}
		}

		public int Decimation { get; set; }

		public ConfigurationSettingsLoader()
		{
            allTraceScales = TraceScaleMap.GetDefaultTraceScales();
            allTraceProbeTypes = TraceProbeMap.GetDefaultTraceProbes();
            allFiringOrders = FiringOrderMap.GetDefaultFiringOrders();
            allSweepTimes = SweepTimeMap.GetDefaultSweepTimes();
            Decimation = 1;
            waveformDataHelper = new WaveformDataHelper(this);
            position = new double[NUMBER_OF_CHANNELS];
            pressureUnits = new PressureUnits[NUMBER_OF_CHANNELS];
            scale = new string[NUMBER_OF_CHANNELS];
            temperatureUnits = new TemperatureUnits[NUMBER_OF_CHANNELS];
            unitsGain = new float[NUMBER_OF_CHANNELS];
			vacuumUnits = new VacuumUnits[NUMBER_OF_CHANNELS];
        }

		public void LoadFromFile(string fileName)
		{
			if ((stream = File.Open(fileName, FileMode.Open)) != null)
			{
				GetConfigurationSettings(fileName);
				stream.Close();
			}
		}

        protected void GetConfigurationSettings(string fileName)
        {
            configurationSettings = new ConfigurationSettings();
            binaryReader = new BinaryReader(stream);

            // Try to parse header
            try
            {
                GetLsmHeaderByMagic();
                GetCScopeModuleValueFromFile(ref fieldValueInt);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"GetCScopeModuleValueFromFile Error: {ex}");
                configurationSettings.ScopeSettings = null;
                return;
            }

            // Initialize settings by file extension
            string extension = Path.GetExtension(fileName).ToLowerInvariant();
            InitializeScopeSettings(extension);

            int fileVersionTemp = fieldValueInt;
            FileVersion? fileVersion = FileVersionMap.GetFileVersion(fileVersionTemp);
            bool isKnown = FileVersionMap.IsKnownFileVersion(fileVersionTemp);

            if (!isKnown)
            {
                throw new Exception($"Unsupported file version: {fileVersionTemp}");
            }

            // Load version-specific settings
            try
            {
                GetSettingsFromFileByVersion(fileVersion);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"GetSettingsFromFileByVersion Error: {ex}");
                configurationSettings.ScopeSettings = null;
                return;
            }

            // Sanity check and finalize
            VerifyScaleIsSet();

            // Only certain extensions support frames, others gave us null reference or index bound exceptions (possibly config only files?)
            var frameExtensions = ScopeFileExtensionMap.FrameFileExtensions;
            if (frameExtensions.Contains(extension))
            {
                try
                {
                    waveformDataHelper.ReadFrameFromVersion(binaryReader, fileVersion, extension);
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"LSMFileReader.ReadFrameFromVersion Error: {ex}");
                    configurationSettings.ScopeSettings = null;
                }
            }
        }

        public void InitializeScopeSettings(string fileExt)
        {
            if (string.IsNullOrEmpty(fileExt))
                return;

            string ext = fileExt.ToLowerInvariant();

            if (ScopeFileExtensionMap.IsLabScope(ext))
            {
                configurationSettings.ScopeSettings = new ScopeSettings(
                    ScopeType.ScopeType_LabScope,
                    TraceList.TraceCount.Four,
                    new LabScopeSweepList()
                );
            }
            else if (ScopeFileExtensionMap.IsIgnitionScope(ext))
            {
                configurationSettings.ScopeSettings = new ScopeSettings(
                    ScopeType.ScopeType_IgnitionScope,
                    TraceList.TraceCount.Two,
                    SweepListMap.GetSweepList(0.00005, 20.0)
                );
            }
            else if (ScopeFileExtensionMap.IsGraphingMeter(ext))
            {
                configurationSettings.ScopeSettings = new ScopeSettings(
                    ScopeType.ScopeType_GraphingMeter,
                    TraceList.TraceCount.Two,
                    SweepListMap.GetSweepList(1.0, 3600.0)
                );

                // could probably add ohms, volts, amps here ... we decided ohms due to ohms law, pun intended.
                var ohmsProbe = new TraceProbe(TraceProbeType.TRACE_PROBE_OHMS);
                var ohmsScale = new TraceScale(40.0, TraceScale.Units.Ohms, ohmsProbe.Gain, ohmsProbe.Offset);
                ohmsProbe.TraceScaleList.Add(ohmsScale);
                configurationSettings.ScopeSettings.Probes.Add(ohmsProbe);
            }

            if (configurationSettings.ScopeSettings != null)
            {
                var shuntProbe = new TraceProbe(TraceProbeType.TRACE_PROBE_SHUNT);
                configurationSettings.ScopeSettings.Probes.Add(shuntProbe);
                configurationSettings.ScopeSettings.ScopeHardwareType = ScopeHardwareType.ScopeHardwareType_M6;
            }
        }

        public void GetLsmHeaderByMagic()
        {
            byte[] headerBytes = new byte[LSM_MAGIC.Length];
            stream.Read(headerBytes, 0, headerBytes.Length);

            header = asciiEncoding.GetString(headerBytes).ToUpperInvariant();

            stream.Position = (header == LSM_MAGIC)
                ? LSM_HEADER_LENGTH
                : 0L;
        }

        public void GetCScopeModuleValueFromFile(ref int fieldValueInt)
        {
            fieldValueInt = BinaryFileReadHelper.ReadFieldValue(binaryReader, stream, ScopeModuleRequiredFieldNamesMap.GetFieldNames(), int.Parse);
        }

        public void GetSettingsFromFileByVersion(FileVersion? fileVersion)
		{
            if (fileVersion == FileVersion.V1_0)
			{
				ReadSettingsFrom_v1_0(fileVersion);
				return;
			}
			if (fileVersion == FileVersion.V1_7 || fileVersion == FileVersion.V1_8)
			{
				int m_DataPlatformType = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_DataPlatformType");
			}
            int m_TraceSelection = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_TraceSelection");

            ReadTraceInfos(fileVersion);
			ReadMultimeterSettings(fileVersion);
			ReadChannelInfos(fileVersion);

			int m_SweepRate = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_SweepRate");
            if (IsSweepRateInRange(m_SweepRate))
            {
				object obj = allSweepTimes[m_SweepRate];
				if (obj.GetType() == typeof(double))
				{
					configurationSettings.ScopeSettings.Sweep = configurationSettings.ScopeSettings.Sweeps[(double)obj];
				}
				else
				{
					configurationSettings.ScopeSettings.Sweep = configurationSettings.ScopeSettings.Sweeps[(SweepType)obj];
				}
			}

			int m_TriggerSelection = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_TriggerSelection");
			if (configurationSettings.ScopeSettings.ScopeType == ScopeType.ScopeType_LabScope)
			{
				configurationSettings.ScopeSettings.SelectedTriggers = configurationSettings.ScopeSettings.TriggerList[m_TriggerSelection];
			}
			else if (configurationSettings.ScopeSettings.ScopeType == ScopeType.ScopeType_IgnitionScope)
			{
				if (m_TriggerSelection > 3)
				{
                    m_TriggerSelection -= 2;
				}
				configurationSettings.ScopeSettings.SelectedTriggers = configurationSettings.ScopeSettings.TriggerList[m_TriggerSelection];
			}
			else
			{
				configurationSettings.ScopeSettings.SelectedTriggers = new Trigger(TriggerSource.SourceType.None);
			}

			ReadTriggerInfos(fileVersion);

			int m_CursorSelection = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_CursorSelection");
			ReadCursorInfos(fileVersion);

			int m_ViewType = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_ViewType");
            
			int m_bGridOn = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_bGridOn");
            
			string m_TriggerTextDisplay = BinaryFileReadHelper.ReadStringValueFromFile(binaryReader, stream, "m_TriggerTextDisplay");
            
			int m_ScaleLabelsDisplay = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_ScaleLabelsDisplay");
            
			int m_ScaleDisplayMode = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_ScaleDisplayMode");
            
			int m_BufferPointIndex = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_BufferPointIndex");
			BufferPointIndex = (uint)m_BufferPointIndex;

            int m_BufferPointCount = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_BufferPointCount");
			BufferPointCount = (uint)m_BufferPointCount;
			
			int m_FrozenBufferPointIndex = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_FrozenBufferPointIndex");
			
			int m_SweepWidth = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_SweepWidth");
			SweepWidth = (uint)m_SweepWidth;
			if (fileVersion == FileVersion.V1_1)
			{
				ushort sweepWidth = SweepWidthHelper.GetSweepWidth(configurationSettings.ScopeSettings.Sweep);
				BufferPointIndex = BufferPointIndex * sweepWidth / SweepWidth;
				BufferPointCount = BufferPointCount * sweepWidth / SweepWidth;
			}
			configurationSettings.CurrentBufferPosition = new BufferPosition(BufferPointIndex);
			if (fileVersion == FileVersion.V1_1 || fileVersion == FileVersion.V1_2)
			{
				configurationSettings.ScopeSettings.Ignition.IgnitionType = Ignition_Type.Conventional;
			}
			else
			{
				int m_IgnitionType = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_IgnitionType");
				Ignition ignitionType = GetIgnitionType(m_IgnitionType);
				configurationSettings.ScopeSettings.Ignition.IgnitionType = ignitionType.IgnitionType;
			}
            
            if (fileVersion == FileVersion.V1_1 || fileVersion == FileVersion.V1_2)
			{
				configurationSettings.ScopeSettings.Ignition.NumberOfCylinders = 4u;
				configurationSettings.ScopeSettings.Ignition.FiringOrder = "1 2 3 4";
				configurationSettings.ScopeSettings.Ignition.Polarity = "+ - + -";
			}
			if (fileVersion == FileVersion.V1_3)
			{
				int m_NumberOfCylinders = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_NumberOfCylinders");
			}
			if (IsModernVersion(fileVersion))
			{
				ReadCylinderSettings();
			}
			if (fileVersion == FileVersion.V1_1 || fileVersion == FileVersion.V1_2)
			{
				configurationSettings.ScopeSettings.Ignition.EngineStroke = Cycles.Four;
			}
			else if (IsModernVersion(fileVersion))
			{
				int m_EngineStroke = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_EngineStroke");
				Ignition ignitionEngineStroke = GetIgnitionEngineStroke(m_EngineStroke);
				configurationSettings.ScopeSettings.Ignition.EngineStroke = ignitionEngineStroke.EngineStroke;
			}
		}
        private bool IsSweepRateInRange(int rate) => rate >= 0 && rate < allSweepTimes.Count + DEFAULT_SWEEP_SETTING_COUNT;

        public void ReadSettingsFrom_v1_0(FileVersion? fileVersion)
		{
			int m_BackgroundColor = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_BackgroundColor");
			int m_TraceSelection = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_TraceSelection");

			ReadTraceInfos(fileVersion);
			ReadChannelInfos(fileVersion);

			int m_SweepRate = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_TraceSelection");
			if (IsSweepRateInRange(m_SweepRate))
			{
				object obj = allSweepTimes[m_SweepRate];
				if (obj.GetType() == typeof(double))
				{
					configurationSettings.ScopeSettings.Sweep = configurationSettings.ScopeSettings.Sweeps[(double)obj];
				}
				else
				{
					configurationSettings.ScopeSettings.Sweep = configurationSettings.ScopeSettings.Sweeps[(SweepType)obj];
				}
			}
			SweepWidth = EXTENDED_SWEEP_WIDTH;

			int m_TriggerSelection = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_TriggerSelection");
			if (configurationSettings.ScopeSettings.ScopeType == ScopeType.ScopeType_LabScope)
			{
				configurationSettings.ScopeSettings.SelectedTriggers = configurationSettings.ScopeSettings.TriggerList[m_TriggerSelection];
			}
			else if (configurationSettings.ScopeSettings.ScopeType == ScopeType.ScopeType_IgnitionScope)
			{
				if (m_TriggerSelection > 3)
				{
                    m_TriggerSelection -= 2;
				}
				configurationSettings.ScopeSettings.SelectedTriggers = configurationSettings.ScopeSettings.TriggerList[m_TriggerSelection];
			}
			else
			{
				configurationSettings.ScopeSettings.SelectedTriggers = new Trigger(TriggerSource.SourceType.None);
			}
			ReadTriggerInfos(fileVersion);

			int m_CursorSelection = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_CursorSelection");
			ReadCursorInfos(fileVersion);

            string m_bDigitalReadOutTracesDisplayed = BinaryFileReadHelper.ReadStringValueFromFile(binaryReader, stream, "m_bDigitalReadOutTracesDisplayed");
            string m_bDigitalReadOutRPMDisplayed = BinaryFileReadHelper.ReadStringValueFromFile(binaryReader, stream, "m_bDigitalReadOutRPMDisplayed");
            string m_ViewType = BinaryFileReadHelper.ReadStringValueFromFile(binaryReader, stream, "m_ViewType");

            int m_bGridOn = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_bGridOn");

			int m_TriggerTextDisplay = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_TriggerTextDisplay");

            int m_ScaleLabelsDisplay = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_ScaleLabelsDisplay");
            int m_ScaleDisplayMode = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_TriggerTextDm_ScaleDisplayModeisplay");

			int m_BufferPointIndex = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_BufferPointIndex");
			BufferPointIndex = (uint)m_BufferPointIndex;

			int m_BufferPointCount = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_BufferPointCount");
			BufferPointCount = (uint)m_BufferPointCount;

			BufferPointIndex = BufferPointIndex * DEFAULT_SWEEP_WIDTH / SweepWidth;
			BufferPointCount = BufferPointCount * DEFAULT_SWEEP_WIDTH / SweepWidth;

			// This was key to finding the waveform data
			configurationSettings.CurrentBufferPosition = new BufferPosition(BufferPointIndex);

            //doesn't seem to find "m_FrozenBufferPointIndex", "m_SweepWidth", "m_IgnitionType", "m_EngineStroke" in v1_0 only
        }

        public void ReadTraceInfos(FileVersion? fileVersion)
		{
			for (int traceIndex = 0; traceIndex < NUMBER_OF_TRACES; traceIndex++)
			{
                int m_TraceInfos = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_TraceInfos[]");

				if (Is_V1_3_Or_Lower(fileVersion))
				{
                    int TraceInfo = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "TraceInfo");
				}

                ReadTraceSettings(traceIndex, fileVersion);
			}
		}

		public void ReadChannelInfos(FileVersion? fileVersion)
		{
			for (int channelIndex = 0; channelIndex < NUMBER_OF_CHANNELS; channelIndex++)
			{
				int m_ChannelInfos = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_ChannelInfos[]");

				if (Is_V1_3_Or_Lower(fileVersion))
				{
					int ChannelInfo = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "ChannelInfo");
				}

				ReadChannelSettings(channelIndex, fileVersion);
			}
		}

        private bool Is_V1_3_Or_Lower(FileVersion? fileVersion)
        {
			return fileVersion == FileVersion.V1_0 || fileVersion == FileVersion.V1_1 || fileVersion == FileVersion.V1_2 || fileVersion == FileVersion.V1_3;
        }

        public void ReadTriggerInfos(FileVersion? fileVersion)
		{
			for (int triggerIndex = 0; triggerIndex < NUMBER_OF_TRIGGERS; triggerIndex++)
			{
				int m_TriggerInfos = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_TriggerInfos[]");

				if (Is_V1_3_Or_Lower(fileVersion))
				{
					int TriggerInfo = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "TriggerInfo");
				}
				if (fileVersion == FileVersion.V1_0)
				{
					GetTriggerSettingsFromFileVersion_1_0(triggerIndex);
				}
				else
				{
					GetTriggerSettingsFromFile(triggerIndex, fileVersion);
				}
			}
		}

		public void ReadCursorInfos(FileVersion? fileVersion)
		{
			for (int cursorIndex = 0; cursorIndex < NUMBER_OF_CURSORS; cursorIndex++)
			{
                int m_CursorInfos = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_CursorInfos[]");
				if (cursorIndex != m_CursorInfos)
				{
					throw new Exception("Cursor Info not found");
				}
				if (fileVersion == FileVersion.V1_0 || fileVersion == FileVersion.V1_1 || fileVersion == FileVersion.V1_2 || fileVersion == FileVersion.V1_3)
				{
					int CursorInfo = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "CursorInfo");
				}
				GetCursorSettingsFromFile(cursorIndex, fileVersion);
			}
		}

		public void ReadCylinderSettings()
		{
			string firingOrder = string.Empty;
			string polarity = string.Empty;

            int m_FiringOrder = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_FiringOrder");
			if (m_FiringOrder >= 0 && m_FiringOrder < allFiringOrders.Count)
			{
				firingOrder = (string)allFiringOrders[m_FiringOrder];
			}

			int m_NumberOfCylinders = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_NumberOfCylinders");
			uint numberOfCylinders = (uint)m_NumberOfCylinders;
			configurationSettings.ScopeSettings.Ignition.NumberOfCylinders = numberOfCylinders;
			configurationSettings.ScopeSettings.Ignition.FiringOrder = firingOrder;

			int m_CylinderPolarities = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_CylinderPolarities");
			if (configurationSettings.ScopeSettings.Ignition.IgnitionType == Ignition_Type.WasteSpark || numberOfCylinders % 2u == 0)
			{
				polarity = GetIgnitionPolarity(numberOfCylinders, m_CylinderPolarities);
			}
			configurationSettings.ScopeSettings.Ignition.Polarity = polarity;
		}

		public void ReadTraceSettings(int index, FileVersion? fileVersion)
        {
			if (fileVersion != FileVersion.V1_0)
			{
                // V1_0 files do not appear to have id which seems suspicious
                int m_id = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_Id");
				configurationSettings.ScopeSettings.TraceList[index].Id.Value = m_id + 1;
			}

            int m_Displayed = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_Displayed");
            configurationSettings.ScopeSettings.TraceList[index].Enabled.Value = Convert.ToBoolean(m_Displayed);

            int m_InputType = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_InputType");

			double m_Position = BinaryFileReadHelper.ReadDoubleValueFromFile(binaryReader, stream, "m_Position");
            position[index] = m_Position;

            int m_Scale = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_Scale");
            if (m_Scale >= 0 && m_Scale < allTraceScales.Count)
            {
                scale[index] = (string)allTraceScales[m_Scale];
            }

            int m_Inverted = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_Inverted");
            if (IsLabScopeOrChannelAB(index))
            {
                configurationSettings.ScopeSettings.TraceList[index].Inverted.Value = Convert.ToBoolean(m_Inverted);
            }

			if(fileVersion == FileVersion.V1_0)
			{
                // m_Color only appears to be in V1_0, we saw very few of these
                int m_Color = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_Color");
            }

            int m_LabelDisplayed = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_LabelDisplayed");

            string m_LabelText = BinaryFileReadHelper.ReadStringValueFromFile(binaryReader, stream, "m_LabelText");

            if (fileVersion == FileVersion.V1_0)
            {
                // m_LabelColor only appears to be in V1_0, we saw very few of these
                int m_LabelColor = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_LabelColor");
            }

            int m_SettingsDisplayed = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_SettingsDisplayed");

            double m_PositionIncrement = BinaryFileReadHelper.ReadDoubleValueFromFile(binaryReader, stream, "m_PositionIncrement");

            double m_MinPosition = BinaryFileReadHelper.ReadDoubleValueFromFile(binaryReader, stream, "m_MinPosition");

            double m_MaxPosition = BinaryFileReadHelper.ReadDoubleValueFromFile(binaryReader, stream, "m_MaxPosition");

            double m_UnitsPerVolt = BinaryFileReadHelper.ReadDoubleValueFromFile(binaryReader, stream, "m_UnitsPerVolt");
            SetUnitGain(index, m_UnitsPerVolt);

            int m_Precision = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_Precision");

            string m_UnitsText = BinaryFileReadHelper.ReadStringValueFromFile(binaryReader, stream, "m_UnitsText");
            GetVacPresTempUnit(index, fieldValueString);

            int m_bInvertedByChangeInProbeType = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_bInvertedByChangeInProbeType");

            int m_AutoScale = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_AutoScale");

            if (IsModernVersion(fileVersion))
            {
				// these settings only appeared in V1_3, V1_7, V1_8 (note: we received no v1_4, v1_5, v1_6 sample files though)
                double m_RasterSpacing = BinaryFileReadHelper.ReadDoubleValueFromFile(binaryReader, stream, "m_RasterSpacing");
                int m_CylinderCount = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_CylinderCount");
                int m_CylinderDisplayed = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_CylinderDisplayed");
            }
        }

        // some settings like inverting don't seem to apply to all channels, example resistance channel which seems to always be >2
		private bool IsLabScopeOrChannelAB(int index)
        {
            return (configurationSettings.ScopeSettings.ScopeType == ScopeType.ScopeType_LabScope || index < 2);
        }

		public void ReadMultimeterSettings(FileVersion? fileVersion)
		{
            //these Multimeter Settings don't appear to be used, but needed to be read to move to the next items in the file

            if (fileVersion == FileVersion.V1_1 || fileVersion == FileVersion.V1_2 || fileVersion == FileVersion.V1_3)
			{
				// this was an odd one is was in v1_1, 1_2 and 1_3.  Usually 1_3 seemed to be first version to follow later standards.
				int MultimeterInfo = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "MultimeterInfo");
			}

            int m_MultimeterProbeType = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_MultimeterProbeType");
            int m_MultimeterCouplingType = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_MultimeterCouplingType");
            int m_MultimeterScale = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_MultimeterScale");
            int m_MultimeterEnabled = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_MultimeterEnabled");
            double m_MultimeterLeadResistance = BinaryFileReadHelper.ReadDoubleValueFromFile(binaryReader, stream, "m_MultimeterLeadResistance");
		}

		public void ReadChannelSettings(int index, FileVersion? fileVersion)
		{
			int m_ChannelId = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_ChannelId");
			int m_ChannelProbeType = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_ChannelProbeType");
			if (IsLabScopeOrChannelAB(index))
			{
				if (fieldValueInt >= 0 && fieldValueInt < allTraceProbeTypes.Count)
				{
					configurationSettings.ScopeSettings.TraceList[index].Probe = configurationSettings.ScopeSettings.Probes[allTraceProbeTypes[m_ChannelProbeType]];
				}
				if (configurationSettings.ScopeSettings.TraceList[index].Probe.IsPressureProbe(configurationSettings.ScopeSettings.TraceList[index].Probe.Type))
				{
					configurationSettings.ScopeSettings.TraceList[index].Probe.SetPressureUnits(pressureUnits[index]);
					configurationSettings.ScopeSettings.PressureUnits = pressureUnits[index];
				}
				else if (configurationSettings.ScopeSettings.TraceList[index].Probe.IsVacuumProbe(configurationSettings.ScopeSettings.TraceList[index].Probe.Type))
				{
					configurationSettings.ScopeSettings.TraceList[index].Probe.SetVacuumUnits(vacuumUnits[index]);
					configurationSettings.ScopeSettings.VacuumUnits = vacuumUnits[index];
				}
				else if (configurationSettings.ScopeSettings.TraceList[index].Probe.IsTemperatureProbe(configurationSettings.ScopeSettings.TraceList[index].Probe.Type))
				{
					configurationSettings.ScopeSettings.TraceList[index].Probe.SetTemperatureUnits(temperatureUnits[index]);
					configurationSettings.ScopeSettings.TemperatureUnits = temperatureUnits[index];
				}
				configurationSettings.ScopeSettings.TraceList[index].Scale = configurationSettings.ScopeSettings.TraceList[index].Probe.TraceScaleList[scale[index]];
				configurationSettings.ScopeSettings.TraceList[index].Probe.SelectedScale = configurationSettings.ScopeSettings.TraceList[index].Probe.TraceScaleList[scale[index]];
				configurationSettings.ScopeSettings.TraceList[index].Position.Value = position[index] * (double)unitsGain[index];
			}
			int m_ChannelCouplingType = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_ChannelCouplingType");
			TraceCoupling traceCoupling = GetTraceCoupling(m_ChannelCouplingType);
			if (IsLabScopeOrChannelAB(index))
			{
				configurationSettings.ScopeSettings.TraceList[index].Coupling = traceCoupling;
            }

            int m_ChannelScale = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_ChannelScale");
			int m_ChannelEnabled = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_ChannelEnabled");

			if (fileVersion != FileVersion.V1_0)
			{
                //V1_0 files do not appear to have any of these properties, but we had very limited samples of this version
                int m_PeakDetectState = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_PeakDetectState");
				TracePeakDetect traceDetect = GetTraceDetect(m_PeakDetectState);
				if (IsLabScopeOrChannelAB(index))
				{
					configurationSettings.ScopeSettings.TraceList[index].PeakDetect = traceDetect;
				}

				int m_ChannelFilter = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_ChannelFilter");
				TraceFilter traceFilter = GetTraceFilter(m_ChannelFilter);
				if (IsLabScopeOrChannelAB(index))
				{
					configurationSettings.ScopeSettings.TraceList[index].Filter = traceFilter;
				}

				double m_ThresholdValue = BinaryFileReadHelper.ReadDoubleValueFromFile(binaryReader, stream, "m_ThresholdValue");
				int m_ThresholdSlope = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_ThresholdSlope");
				ThresholdSlope traceThresholdSlope = GetTraceThresholdSlope(m_ThresholdSlope);
				if (IsLabScopeOrChannelAB(index))
				{
					configurationSettings.ScopeSettings.TraceList[index].ThresholdSlope = traceThresholdSlope;
				}
				int m_PulseScale = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_PulseScale");
				int m_bPeakDetectByChangeInProbeType = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_bPeakDetectByChangeInProbeType");
			}

            if (fileVersion == FileVersion.V1_7 || fileVersion == FileVersion.V1_8)
            {
                // ignoring "m_ChannelLeadResistance" only seems to appear in 1.7 and 1.8 possibly?
                double m_ChannelLeadResistance = BinaryFileReadHelper.ReadDoubleValueFromFile(binaryReader, stream, "m_ChannelLeadResistance");
            }
        }

        public void GetTriggerSettingsFromFile(int index, FileVersion? fileVersion)
        {
            int mappedIndex = GetTriggerIndex(index);

            // Source
            int m_TriggerSource = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_TriggerSource");
            configurationSettings.ScopeSettings.TriggerList[mappedIndex].Source = GetTriggerSource(index, m_TriggerSource);

            // Mode
            int m_TriggerMode = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_TriggerMode");
            configurationSettings.ScopeSettings.TriggerList[mappedIndex].Mode = GetTriggerMode(m_TriggerMode);

            // Delay
            double m_TriggerDelay = BinaryFileReadHelper.ReadDoubleValueFromFile(binaryReader, stream, "m_TriggerDelay");
            configurationSettings.ScopeSettings.TriggerList[mappedIndex].Delay.Value = m_TriggerDelay;

            // Level
            double m_TriggerLevel = BinaryFileReadHelper.ReadDoubleValueFromFile(binaryReader, stream, "m_TriggerLevel");
            configurationSettings.ScopeSettings.TriggerList[mappedIndex].Level.Value = m_TriggerLevel;

            // Adjust level for selected trigger
            if (configurationSettings.ScopeSettings.TriggerList[mappedIndex] == configurationSettings.ScopeSettings.TriggerList.SelectedTrigger)
            {
                // Apply gain to level to match known voltage values
                configurationSettings.ScopeSettings.TriggerList[mappedIndex].Level.Value *= unitsGain[index];
                if (configurationSettings.ScopeSettings.TraceList[index].Inverted.Value)
                {
                    configurationSettings.ScopeSettings.TriggerList[mappedIndex].Level.Value *= -1;
                }
            }

            // Slope
            int m_TriggerSlope = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_TriggerSlope");
            configurationSettings.ScopeSettings.TriggerList[mappedIndex].Slope = GetTriggerSlope(m_TriggerSlope);

            // Misc fields (likely padding or extended metadata)
            int m_TriggerDisplayed = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_TriggerDisplayed");

            double m_TriggerDelayIncrement = BinaryFileReadHelper.ReadDoubleValueFromFile(binaryReader, stream, "m_TriggerDelayIncrement");
            double m_TriggerLevelIncrement = BinaryFileReadHelper.ReadDoubleValueFromFile(binaryReader, stream, "m_TriggerLevelIncrement");
            double m_TriggerMinDelay = BinaryFileReadHelper.ReadDoubleValueFromFile(binaryReader, stream, "m_TriggerMinDelay");
            double m_TriggerMaxDelay = BinaryFileReadHelper.ReadDoubleValueFromFile(binaryReader, stream, "m_TriggerMaxDelay");
            double m_TriggerMinLevel = BinaryFileReadHelper.ReadDoubleValueFromFile(binaryReader, stream, "m_TriggerMinLevel");
            double m_TriggerMaxLevel = BinaryFileReadHelper.ReadDoubleValueFromFile(binaryReader, stream, "m_TriggerMaxLevel");

            int m_TriggerActiveColor = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_TriggerActiveColor");

            // Cylinder Number handling
			if (IsModernVersion(fileVersion))
            {
                int m_TriggerCylinder = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_TriggerCylinder");

                if (configurationSettings.ScopeSettings.TriggerList[mappedIndex] == configurationSettings.ScopeSettings.TriggerList.SelectedTrigger)
                {
                    configurationSettings.ScopeSettings.TriggerList[mappedIndex].CylinderNumber.Value = (uint)m_TriggerCylinder;
                }
            }
       }

        private int GetTriggerIndex(int inputIndex)
        {
            if (configurationSettings.ScopeSettings.ScopeType == ScopeType.ScopeType_LabScope)
                return inputIndex;

            if (configurationSettings.ScopeSettings.ScopeType == ScopeType.ScopeType_IgnitionScope)
            {
                // Only first 2 or last 2 seem used — normalize index to 0 or 1
                if (inputIndex < 2)
                    return inputIndex;
                if (inputIndex > 3)
                    return inputIndex - 2;
            }

            return inputIndex; // fallback, should never happen
        }

        public void GetTriggerSettingsFromFileVersion_1_0(int index)
		{
			int triggerSettingsCollectionIndex = 0;
            int m_TriggerSource = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_TriggerSource");
            if (configurationSettings.ScopeSettings.ScopeType == ScopeType.ScopeType_LabScope)
			{
				TriggerSource triggerSource = GetTriggerSource(index, m_TriggerSource);
				configurationSettings.ScopeSettings.TriggerList[index].Source = triggerSource;
			}
			else if (configurationSettings.ScopeSettings.ScopeType == ScopeType.ScopeType_IgnitionScope)
			{
				if (index < 2)
				{
					TriggerSource triggerSource2 = GetTriggerSource(index, m_TriggerSource);
					configurationSettings.ScopeSettings.TriggerList[index].Source = triggerSource2;
				}
				else if (index > 3)
				{
					TriggerSource triggerSource3 = GetTriggerSource(index, m_TriggerSource);
					configurationSettings.ScopeSettings.TriggerList[index - 2].Source = triggerSource3;
				}
			}

            int m_TriggerMode = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_TriggerMode");

            double m_TriggerDelay = BinaryFileReadHelper.ReadDoubleValueFromFile(binaryReader, stream, "m_TriggerDelay");

            double m_TriggerLevel = BinaryFileReadHelper.ReadDoubleValueFromFile(binaryReader, stream, "m_TriggerLevel");
            if (configurationSettings.ScopeSettings.ScopeType == ScopeType.ScopeType_LabScope)
			{
				configurationSettings.ScopeSettings.TriggerList[index].Level.Value = m_TriggerLevel;
			}
			else if (configurationSettings.ScopeSettings.ScopeType == ScopeType.ScopeType_IgnitionScope)
			{
				if (index < 2)
				{
					configurationSettings.ScopeSettings.TriggerList[index].Level.Value = m_TriggerLevel;
				}
				else if (index > 3)
				{
					configurationSettings.ScopeSettings.TriggerList[index - 2].Level.Value = m_TriggerLevel;
				}
			}
			if (configurationSettings.ScopeSettings.ScopeType == ScopeType.ScopeType_LabScope)
			{
				if ((index < 4 && configurationSettings.ScopeSettings.TriggerList[index] == configurationSettings.ScopeSettings.TriggerList.SelectedTrigger)
					|| (configurationSettings.ScopeSettings.ScopeType == ScopeType.ScopeType_IgnitionScope && index < 2 && configurationSettings.ScopeSettings.TriggerList[index] == configurationSettings.ScopeSettings.TriggerList.SelectedTrigger))

                {
                    //apply unit gain to level to match known voltage values
                    configurationSettings.ScopeSettings.TriggerList[index].Level.Value *= unitsGain[index];
					if (configurationSettings.ScopeSettings.TraceList[index].Inverted.Value)
					{
						configurationSettings.ScopeSettings.TriggerList[index].Level.Value = 0.0 - configurationSettings.ScopeSettings.TriggerList[index].Level.Value;
					}
				}
			}

            int m_TriggerSlope = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_TriggerSlope");
            TriggerSlope triggerSlope = GetTriggerSlope(m_TriggerSlope);
			if (configurationSettings.ScopeSettings.ScopeType == ScopeType.ScopeType_LabScope)
			{
				configurationSettings.ScopeSettings.TriggerList[index].Slope = triggerSlope;
			}
			else if (configurationSettings.ScopeSettings.ScopeType == ScopeType.ScopeType_IgnitionScope)
			{
				if (index < 2)
				{
					configurationSettings.ScopeSettings.TriggerList[index].Slope = triggerSlope;
				}
				else if (index > 3)
				{
					configurationSettings.ScopeSettings.TriggerList[index - 2].Slope = triggerSlope;
				}
			}

            int m_TriggerDisplayed = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_TriggerDisplayed");

            double m_TriggerDelayIncrement = BinaryFileReadHelper.ReadDoubleValueFromFile(binaryReader, stream, "m_TriggerDelayIncrement");
            double m_TriggerLevelIncrement = BinaryFileReadHelper.ReadDoubleValueFromFile(binaryReader, stream, "m_TriggerLevelIncrement");
            double m_TriggerMinDelay = BinaryFileReadHelper.ReadDoubleValueFromFile(binaryReader, stream, "m_TriggerMinDelay");
            
			double m_TriggerMaxDelay = BinaryFileReadHelper.ReadDoubleValueFromFile(binaryReader, stream, "m_TriggerMaxDelay");
			m_TriggerDelay = m_TriggerDelay * (m_TriggerMaxDelay - m_TriggerMinDelay) / 600.0;
			if (configurationSettings.ScopeSettings.ScopeType == ScopeType.ScopeType_LabScope)
			{
				configurationSettings.ScopeSettings.TriggerList[index].Delay.Value = m_TriggerDelay;
			}
			else if (configurationSettings.ScopeSettings.ScopeType == ScopeType.ScopeType_IgnitionScope)
			{
				if (index < 2)
				{
					configurationSettings.ScopeSettings.TriggerList[index].Delay.Value = m_TriggerDelay;
				}
				else if (index > 3)
				{
					configurationSettings.ScopeSettings.TriggerList[index - 2].Delay.Value = m_TriggerDelay;
				}
			}

            double m_TriggerMinLevel = BinaryFileReadHelper.ReadDoubleValueFromFile(binaryReader, stream, "m_TriggerMinLevel");
            double m_TriggerMaxLevel = BinaryFileReadHelper.ReadDoubleValueFromFile(binaryReader, stream, "m_TriggerMaxLevel");

            int m_TriggerActiveColor = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_TriggerActiveColor");
		}

		public void GetCursorSettingsFromFile(int index, FileVersion? fileVersion)
		{
            int m_CursorId = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_CursorId");
			configurationSettings.ScopeSettings.Cursors[index].Id.Value = m_CursorId + 1;

            double m_CursorPosition = BinaryFileReadHelper.ReadDoubleValueFromFile(binaryReader, stream, "m_CursorPosition");
			
			int m_CursorDisplayed = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_CursorDisplayed");
			configurationSettings.ScopeSettings.Cursors[index].Enabled.Value = Convert.ToBoolean(m_CursorDisplayed);
			
			int m_CursorSelected = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_CursorSelected");
			double m_CursorPositionIncrement = BinaryFileReadHelper.ReadDoubleValueFromFile(binaryReader, stream, "m_CursorPositionIncrement");

			double m_CursorMinPosition = BinaryFileReadHelper.ReadDoubleValueFromFile(binaryReader, stream, "m_CursorMinPosition");

			double m_CursorMaxPosition = BinaryFileReadHelper.ReadDoubleValueFromFile(binaryReader, stream, "m_CursorMaxPosition");

			if (fileVersion == FileVersion.V1_0)
			{
				// this was not lining up with the default 560, so it appeared to be a wider value like 600?
				m_CursorPosition = m_CursorPosition * (m_CursorMaxPosition - m_CursorMinPosition) / EXTENDED_SWEEP_WIDTH;
			}
			configurationSettings.ScopeSettings.Cursors[index].Position.Value = m_CursorPosition;

			int m_CursorActiveColor = BinaryFileReadHelper.ReadIntegerValueFromFile(binaryReader, stream, "m_CursorActiveColor");
		}

		public void SetUnitGain(int index, double m_UnitsPerVolt)
		{
            switch (scale[index].Split(' ')[1].ToLower())
			{
				case "ma":
				case "mv":
				case "ms":
                    m_UnitsPerVolt /= DEFAULT_UNIT_ADJUSTMENT_FACTOR;
					break;
				case "kv":
				case "khz":
                    m_UnitsPerVolt *= DEFAULT_UNIT_ADJUSTMENT_FACTOR;
					break;
				default:
                    unitsGain[index] = (float)m_UnitsPerVolt;
					break;
            }
		}

		public TraceCoupling GetTraceCoupling(int traceCouplingIndex)
		{
			TraceCoupling traceCoupling = new TraceCoupling();
			if (traceCouplingIndex == 0)
			{
				traceCoupling.Value = TraceCoupling.TraceCouplingType.Coupling_AC;
			}
			return traceCoupling;
		}

		public TracePeakDetect GetTraceDetect(int tracePeakDetectIndex)
		{
			TracePeakDetect tracePeakDetect = new TracePeakDetect();
			if (tracePeakDetectIndex != 0)
			{
				tracePeakDetect.Value = TracePeakDetect.PeakDetectStatus.On;
			}
			return tracePeakDetect;
		}

		public TraceFilter GetTraceFilter(int traceFilterIdx)
		{
			TraceFilter traceFilter = new TraceFilter();
			if (traceFilterIdx != 0)
			{
				traceFilter.Value = FilterState.On;
			}
			return traceFilter;
		}

		public void GetVacPresTempUnit(int index, string unitText)
		{
			string text = unitText.ToLower();
			if (text == null)
			{
				return;
			}
			switch (text.Length)
			{
				case 4:
                    if (text == "inhg")
                    {
                        vacuumUnits[index] = VacuumUnits.inHg;
                    }
                    if (text == "mmhg")
                    {
                        vacuumUnits[index] = VacuumUnits.mmHg;
                    }
                    break;
				case 3:
                    if (text == "kpa")
                    {
                        vacuumUnits[index] = VacuumUnits.kPa;
                        pressureUnits[index] = PressureUnits.kPa;
                    }
                    if (text == "mpa")
                    {
                        pressureUnits[index] = PressureUnits.kPa;
                    }
                    if (text == "psi")
                    {
                        pressureUnits[index] = PressureUnits.psi;
                    }
                    if (text == "bar")
                    {
                        pressureUnits[index] = PressureUnits.bar;
                    }
                    break;
                case 2:
                    if (text == "°f")
                    {
                        temperatureUnits[index] = TemperatureUnits.degF;
                    }
                    if (text == "°c")
                    {
                        temperatureUnits[index] = TemperatureUnits.degC;
                    }
                    break;
				case 6:
					if (text == "kg/cm²")
					{
						pressureUnits[index] = PressureUnits.kgcm2;
					}
					break;
				default:
					break;
			}
		}

		public ThresholdSlope GetTraceThresholdSlope(int thresholdSlopeIndex)
		{
			ThresholdSlope thresholdSlope = new ThresholdSlope();
			if (thresholdSlopeIndex == 0)
			{
				thresholdSlope.Slope = ThresholdSlope.ThresholdSlopeType.Down;
			}
			else
			{
				thresholdSlope.Slope = ThresholdSlope.ThresholdSlopeType.Up;
			}
			return thresholdSlope;
		}

		public TriggerSource GetTriggerSource(int index, int triggerSourceIdx)
		{
			TriggerSource result = new TriggerSource(TriggerSource.SourceType.None);
			switch (triggerSourceIdx)
			{
			case 0:
			case 1:
			case 2:
			case 3:
				result = new TriggerSource(configurationSettings.ScopeSettings.TraceList[index]);
				break;
			case 4:
				result = new TriggerSource(TriggerSource.SourceType.Cylinder);
				break;
			case 5:
				result = new TriggerSource(TriggerSource.SourceType.None);
				break;
			}
			return result;
		}

		public TriggerMode GetTriggerMode(int triggerModeIdx)
		{
			TriggerMode triggerMode = new TriggerMode();
			if (triggerModeIdx == 0)
			{
				triggerMode.Value = TriggerMode.TriggerModeType.Auto;
			}
			else
			{
				triggerMode.Value = TriggerMode.TriggerModeType.Normal;
			}
			return triggerMode;
		}

		public TriggerSlope GetTriggerSlope(int triggerSlopeIdx)
		{
			TriggerSlope triggerSlope = new TriggerSlope();
			if (triggerSlopeIdx == 0)
			{
				triggerSlope.Value = TriggerSlope.SlopeType.Down;
			}
			else
			{
				triggerSlope.Value = TriggerSlope.SlopeType.Up;
			}
			return triggerSlope;
		}

		public Ignition GetIgnitionType(int ignitionTypeIdx)
		{
			Ignition ignition = new Ignition();
			switch (ignitionTypeIdx)
			{
			case 1:
				ignition.IgnitionType = Ignition_Type.Conventional;
				break;
			case 2:
				ignition.IgnitionType = Ignition_Type.WasteSpark;
				break;
			case 3:
				ignition.IgnitionType = Ignition_Type.Direct;
				break;
			case 4:
				ignition.IgnitionType = Ignition_Type.Other;
				break;
			default:
				ignition.IgnitionType = Ignition_Type.Conventional;
				break;
			}
			return ignition;
		}

		public string GetIgnitionPolarity(uint numCylinder, int ignitionPolarityIndex)
		{
			string text = string.Empty;
			uint totalPolarities = 2 * numCylinder - 1;
			if (ignitionPolarityIndex != 0)
			{
				for (int i = 0; i < totalPolarities; i += 2)
				{
					text = (((ignitionPolarityIndex & 1) != 1) ? (text + "-") : (text + "+"));
					text += " ";
					ignitionPolarityIndex >>= 1;
				}
				if (!VerifyPolarity(text))
				{
					text = BuildDefaultPolarity();
				}
			}
			else
			{
				text = BuildDefaultPolarity();
			}
			return text;
		}

        public string BuildDefaultPolarity()
        {
            string polarity = "";
            bool isPositive = true;
            uint cylinderCount = configurationSettings.ScopeSettings.Ignition.NumberOfCylinders;

            for (int i = 0; i < cylinderCount; i++)
            {
                polarity += isPositive ? "+" : "-";
                polarity += " ";
                isPositive = !isPositive;
            }

            if (cylinderCount % 4u == 0)
            {
                char[] chars = polarity.ToCharArray();
                for (int j = (int)cylinderCount; j < chars.Length; j += 2)
                {
                    chars[j] = chars[j] == '+' ? '-' : '+';
                }
                polarity = new string(chars);
            }

            return polarity;
        }

        public bool VerifyPolarity(string polarity)
        {
            int expectedLength = (int)configurationSettings.ScopeSettings.Ignition.NumberOfCylinders;
            string compactPolarity = polarity.Replace(" ", "");

            if (compactPolarity.Length != expectedLength)
            {
                return false;
            }

            int plusCount = 0;
            int minusCount = 0;

            foreach (char c in polarity)
            {
                if (c == '+') plusCount++;
                else if (c == '-') minusCount++;
            }

            return plusCount == minusCount;
        }


        public Ignition GetIgnitionEngineStroke(int engineStrokeIndex)
		{
			Ignition ignition = new Ignition() {  EngineStroke = engineStrokeIndex == 0 ? Cycles.Two : Cycles.Four };
			return ignition;
		}

		public void VerifyScaleIsSet()
		{
			foreach (Trace trace in configurationSettings.ScopeSettings.TraceList)
			{
				if(trace.Scale == null)
				{
                    trace.Scale = trace.Probe.TraceScaleList[20.0];
                    trace.Probe.SelectedScale = trace.Probe.TraceScaleList[20.0];
                }
			}
		}

        private bool IsModernVersion(FileVersion? v) => v == FileVersion.V1_3 || v == FileVersion.V1_7 || v == FileVersion.V1_8;
	}
}