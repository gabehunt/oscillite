using System;

namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public class TriggerDelay : Position<double>
	{
		public TriggerDelay()
			: base(0.0)
		{
		}

		public TriggerDelay(double position)
			: base(position)
		{
		}
	}
}
