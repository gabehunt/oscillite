﻿namespace Oscillite.CleanRoom.LSM
{
    public static class SweepLabels
    {
        public const string SweepMicroseconds = "µs";
        public const string SweepMilliseconds = "ms";
        public const string SweepSeconds = "s";
        public const string SweepMinutes = "min";
        public const string SweepHours = "hr";
    }
}
