using System;
using System.Xml.Serialization;

namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public enum ScopeType
	{
		[XmlEnum(Name = "LS")]
		ScopeType_LabScope,
		[XmlEnum(Name = "GM")]
		ScopeType_GraphingMeter,
		[XmlEnum(Name = "IS")]
		ScopeType_IgnitionScope,
		[XmlEnum(Name = "DM")]
		ScopeType_DigitalMeter
	}
}
