using System;

namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public class TestLeadMcDwell90TraceScaleList : TraceScaleList
	{
		public TestLeadMcDwell90TraceScaleList(float probeGain, float probeOffset)
			: base(TraceProbeType.TRACE_PROBE_MCDWELL_90, hasAutoScale: false)
		{
			Add(new TraceScale(30.0, TraceScale.Units.Degree, probeGain, probeOffset));
			Add(new TraceScale(60.0, TraceScale.Units.Degree, probeGain, probeOffset));
			Add(new TraceScale(90.0, TraceScale.Units.Degree, probeGain, probeOffset));
			base.SelectedScale = base[base.Count - 1];
		}
	}
}
