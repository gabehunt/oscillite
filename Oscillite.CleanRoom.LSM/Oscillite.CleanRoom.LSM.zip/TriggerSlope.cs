using System;
using System.Xml.Serialization;

namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public class TriggerSlope
	{
		public enum SlopeType
		{
			[XmlEnum(Name = "U")]
			Up,
			[XmlEnum(Name = "D")]
			Down
		}

		private SlopeType slope;

		[XmlAttribute("V")]
		public SlopeType Value
		{
			get
			{
				return slope;
			}
			set
			{
				slope = value;
			}
		}

		public TriggerSlope()
		{
			slope = SlopeType.Up;
		}

		public TriggerSlope(SlopeType slope)
		{
			this.slope = slope;
		}
	}
}
