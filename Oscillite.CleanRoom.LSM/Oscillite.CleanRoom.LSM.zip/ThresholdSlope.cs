using System;
using System.Xml.Serialization;

namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public class ThresholdSlope
	{
		public enum ThresholdSlopeType
		{
			[XmlEnum(Name = "U")]
			Up,
			[XmlEnum(Name = "D")]
			Down
		}

		private ThresholdSlopeType slope = ThresholdSlopeType.Down;

		[XmlAttribute("V")]
		public ThresholdSlopeType Slope
		{
			get
			{
				return slope;
			}
			set
			{
				slope = value;
			}
		}

		public ThresholdSlope()
		{
			slope = ThresholdSlopeType.Down;
		}
	}
}
