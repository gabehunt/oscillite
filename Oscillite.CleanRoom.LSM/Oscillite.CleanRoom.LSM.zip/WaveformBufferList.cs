using System;
using System.Collections.Generic;

namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public class WaveformBufferList : List<WaveformBuffer>
	{
	}
}
