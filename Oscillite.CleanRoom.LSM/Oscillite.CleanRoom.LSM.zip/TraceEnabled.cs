using System;
using System.Xml.Serialization;

namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public class TraceEnabled
	{
		private bool enabled = false;

		[XmlAttribute("V")]
		public bool Value
		{
			get
			{
				return enabled;
			}
			set
			{
				enabled = value;
			}
		}

	}
}
