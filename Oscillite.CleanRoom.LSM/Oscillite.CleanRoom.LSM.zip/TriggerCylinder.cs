using System;
using System.Xml.Serialization;

namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public class TriggerCylinder
	{
		private uint cylinderNumber = 1u;

		[XmlAttribute("V")]
		public uint Value
		{
			get
			{
				return cylinderNumber;
			}
			set
			{
				cylinderNumber = value;
			}
		}

		public TriggerCylinder(uint cylinderNumber)
		{
			this.cylinderNumber = cylinderNumber;
		}

	}
}
