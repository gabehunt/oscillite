using System;

namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public class TriggerLevel : Position<double>
	{
		public TriggerLevel()
			: base(0.0)
		{
		}

		public TriggerLevel(double position)
			: base(position)
		{
		}
	}
}
