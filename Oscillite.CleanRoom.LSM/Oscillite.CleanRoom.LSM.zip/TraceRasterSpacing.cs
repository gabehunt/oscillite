using System;

namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public class TraceRasterSpacing : Position<double>
	{
		public TraceRasterSpacing()
			: base(0.0)
		{
		}

		public TraceRasterSpacing(double spacing)
			: base(spacing)
		{
		}
	}
}
