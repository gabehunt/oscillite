﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Oscillite.CleanRoom.LSM
{
    public enum FilterState
    {
        [XmlEnum(Name = "On")]
        On,
        [XmlEnum(Name = "D")]
        Disabled,
        [XmlEnum(Name = "Off")]
        Off
    }
}
