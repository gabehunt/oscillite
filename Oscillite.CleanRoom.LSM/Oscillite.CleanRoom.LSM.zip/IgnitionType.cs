﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Oscillite.CleanRoom.LSM
{
    public enum Ignition_Type
    {
        [XmlEnum(Name = "Cl")]
        Conventional,
        [XmlEnum(Name = "WS")]
        WasteSpark,
        [XmlEnum(Name = "D")]
        Direct,
        [XmlEnum(Name = "O")]
        Other
    }
}
