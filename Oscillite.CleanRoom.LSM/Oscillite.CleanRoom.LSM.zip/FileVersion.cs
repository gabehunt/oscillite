﻿namespace Oscillite.CleanRoom.LSM
{
    public enum FileVersion
    {
        V1_0,
        V1_1,
        V1_2,
        V1_3,
        V1_7,
        V1_8
    }
}
