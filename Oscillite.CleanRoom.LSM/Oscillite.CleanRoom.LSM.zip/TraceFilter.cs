using System;
using System.Xml.Serialization;

namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public class TraceFilter
	{
		private FilterState status = FilterState.Off;

		[XmlAttribute("V")]
		public FilterState Value
		{
			get
			{
				return status;
			}
			set
			{
				status = value;
			}
		}
	}
}
