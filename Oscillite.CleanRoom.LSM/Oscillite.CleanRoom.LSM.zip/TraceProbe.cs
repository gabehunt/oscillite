using System;
using System.Xml.Serialization;
using Oscillite.CleanRoom.LSM.Properties;


namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public class TraceProbe
	{
		private TraceProbeType type = TraceProbeType.TRACE_PROBE_VOLTS;

		private string name;

		private TraceScaleList scales;

		private float gain = 1f;

		private float offset = 0f;

		public VacuumUnits VacuumUnits = VacuumUnits.mmHg;

        public PressureUnits PressureUnits;

        public TemperatureUnits TemperatureUnits = TemperatureUnits.degF;

		private bool isSupported;

		private bool isCalibrationSupported;

		[XmlAttribute("T")]
		public TraceProbeType Type
		{
			get
			{
				return type;
			}
			set
			{
				type = value;
			}
		}

		[XmlAttribute("N")]
		public string Name
		{
			get
			{
				return name;
			}
			set
			{
				name = value;
			}
		}

		[XmlArray("TSL")]
		[XmlArrayItem("TS")]
		public TraceScaleList TraceScaleList
		{
			get
			{
				return scales;
			}
			set
			{
				scales = value;
			}
		}

		[XmlElement("SS")]
		public TraceScale SelectedScale
		{
			get
			{
				return scales.SelectedScale;
			}
			set
			{
				scales.SelectedScale = value;
			}
		}

		[XmlAttribute("G")]
		public float Gain
		{
			get
			{
				return gain;
			}
			set
			{
				gain = value;
			}
		}

		[XmlAttribute("O")]
		public float Offset
		{
			get
			{
				return offset;
			}
			set
			{
				offset = value;
			}
		}

		public TraceProbe()
		{
            gain = 1f;
            offset = 0f;
            TraceProbeFactory.ConfigureProbe(this, PressureUnits.psi, TemperatureUnits.degC, VacuumUnits.mmHg);
        }

        public TraceProbe(TraceProbeType type)
		{
			gain = 1f;
			offset = 0f;
            this.type = type;
            TraceProbeFactory.ConfigureProbe(this, PressureUnits.psi, TemperatureUnits.degC, VacuumUnits.mmHg);
		}

		public TraceProbe(TraceProbeType type, PressureUnits pressureUnits)
		{
            gain = 1f;
			offset = 0f;
            this.type = type;
            TraceProbeFactory.ConfigureProbe(this, pressureUnits, TemperatureUnits.degC, VacuumUnits.mmHg);
		}

		public TraceProbe(TraceProbeType type, VacuumUnits vacuumUnits)
		{
			gain = 1f;
			offset = 0f;
            this.type = type;
            TraceProbeFactory.ConfigureProbe(this, PressureUnits.psi, TemperatureUnits.degC, vacuumUnits);
		}

		public TraceProbe(TraceProbeType type, TemperatureUnits temperatureUnits)
		{
			this.type = type;
			gain = 1f;
			offset = 0f;
			TraceProbeFactory.ConfigureProbe(this, PressureUnits.psi, temperatureUnits, VacuumUnits.mmHg);
		}

		public bool IsCalculatedProbe()
		{
			bool result = false;
			if (type == TraceProbeType.TRACE_PROBE_DUTY_CYCLE || type == TraceProbeType.TRACE_PROBE_FREQUENCY || type == TraceProbeType.TRACE_PROBE_INJECTOR_PULSE_WIDTH || type == TraceProbeType.TRACE_PROBE_MCDWELL_60 || type == TraceProbeType.TRACE_PROBE_MCDWELL_90 || type == TraceProbeType.TRACE_PROBE_PULSE_WIDTH)
			{
				result = true;
			}
			return result;
		}

		public bool IsPressureProbe(TraceProbeType probeType)
		{
			bool result = false;
			if (probeType == TraceProbeType.TRACE_PROBE_PRESSURE_100 || probeType == TraceProbeType.TRACE_PROBE_PRESSURE_500 || probeType == TraceProbeType.TRACE_PROBE_PRESSURE_5000 || probeType == TraceProbeType.TRACE_PROBE_MT5030_PRESSURE)
			{
				result = true;
			}
			return result;
		}

		public bool IsVacuumProbe(TraceProbeType probeType)
		{
			bool result = false;
			if (probeType == TraceProbeType.TRACE_PROBE_VACUUM_100 || probeType == TraceProbeType.TRACE_PROBE_MT5030_VACUUM)
			{
				result = true;
			}
			return result;
		}

		public bool IsTemperatureProbe(TraceProbeType probeType)
		{
			bool result = false;
			if (probeType == TraceProbeType.TRACE_PROBE_EEDM506D_TEMPERATURE)
			{
				result = true;
			}
			return result;
		}

		public void SetPressureUnits(PressureUnits pressureUnits)
		{
			TraceProbeFactory.ConfigureProbe(this, pressureUnits, TemperatureUnits.degC, VacuumUnits.mmHg);
		}

		public void SetVacuumUnits(VacuumUnits vacuumUnits)
		{
			TraceProbeFactory.ConfigureProbe(this, PressureUnits.psi, TemperatureUnits.degC, vacuumUnits);
		}

		public void SetTemperatureUnits(TemperatureUnits temperatureUnits)
		{
            TraceProbeFactory.ConfigureProbe(this, PressureUnits.psi, temperatureUnits, VacuumUnits.mmHg);
		}
	}
}
