using System;
using System.Xml.Serialization;

namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public class TraceInverted
	{
		private bool m_inverted;

		[XmlAttribute("V")]
		public bool Value
		{
			get
			{
				return m_inverted;
			}
			set
			{
				m_inverted = value;
			}
		}

		public TraceInverted()
		{
			m_inverted = false;
		}

		public TraceInverted(bool inverted)
		{
			m_inverted = inverted;
		}

		public TraceInverted(TraceInverted inverted)
		{
			m_inverted = inverted.m_inverted;
		}		
	}
}
