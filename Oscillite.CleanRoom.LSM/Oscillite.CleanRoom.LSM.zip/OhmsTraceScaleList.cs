using System;

namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public class OhmsTraceScaleList : TraceScaleList
	{
		public OhmsTraceScaleList(float probeGain, float probeOffset)
			: base(TraceProbeType.TRACE_PROBE_OHMS, hasAutoScale: true)
		{
			Add(new TraceScale(40.0, TraceScale.Units.Ohms, probeGain, probeOffset));
			Add(new TraceScale(400.0, TraceScale.Units.Ohms, probeGain, probeOffset));
			Add(new TraceScale(4000.0, TraceScale.Units.kOhms, probeGain, probeOffset));
			Add(new TraceScale(40000.0, TraceScale.Units.kOhms, probeGain, probeOffset));
			Add(new TraceScale(400000.0, TraceScale.Units.kOhms, probeGain, probeOffset));
			Add(new TraceScale(4000000.0, TraceScale.Units.MOhms, probeGain, probeOffset));
			Add(new TraceScale(40000000.0, TraceScale.Units.MOhms, probeGain, probeOffset));
			base.SelectedScale = base[base.Count - 1];
		}
	}
}
