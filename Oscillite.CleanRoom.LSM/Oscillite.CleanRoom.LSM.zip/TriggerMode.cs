using System;
using System.Xml.Serialization;

namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public class TriggerMode
	{
		public enum TriggerModeType
		{
			[XmlEnum(Name = "Auto")]
			Auto,
			[XmlEnum(Name = "Normal")]
			Normal
		}

		private TriggerModeType mode = TriggerModeType.Normal;

		[XmlAttribute("V")]
		public TriggerModeType Value
		{
			get
			{
				return mode;
			}
			set
			{
				mode = value;
			}
		}

		public TriggerMode()
		{
			mode = TriggerModeType.Auto;
		}

		public TriggerMode(TriggerModeType mode)
		{
			this.mode = mode;
		}
	}
}
