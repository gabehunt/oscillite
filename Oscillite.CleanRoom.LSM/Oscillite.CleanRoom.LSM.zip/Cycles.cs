﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Oscillite.CleanRoom.LSM
{
    public enum Cycles
    {
        [XmlEnum(Name = "2")]
        Two,
        [XmlEnum(Name = "4")]
        Four
    }
}
