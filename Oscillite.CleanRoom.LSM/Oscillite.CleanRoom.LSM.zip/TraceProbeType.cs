﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Oscillite.CleanRoom.LSM
{
    public enum TraceProbeType
    {
        [XmlEnum(Name = "V")]
        TRACE_PROBE_VOLTS,
        [XmlEnum(Name = "M60")]
        TRACE_PROBE_MCDWELL_60,
        [XmlEnum(Name = "M90")]
        TRACE_PROBE_MCDWELL_90,
        [XmlEnum(Name = "IPW")]
        TRACE_PROBE_INJECTOR_PULSE_WIDTH,
        [XmlEnum(Name = "PW")]
        TRACE_PROBE_PULSE_WIDTH,
        [XmlEnum(Name = "DC")]
        TRACE_PROBE_DUTY_CYCLE,
        [XmlEnum(Name = "F")]
        TRACE_PROBE_FREQUENCY,
        [XmlEnum(Name = "VAC")]
        TRACE_PROBE_VOLTS_AC,
        [XmlEnum(Name = "VDC")]
        TRACE_PROBE_VOLTS_DC,
        [XmlEnum(Name = "V100")]
        TRACE_PROBE_VACUUM_100,
        [XmlEnum(Name = "P100")]
        TRACE_PROBE_PRESSURE_100,
        [XmlEnum(Name = "P500")]
        TRACE_PROBE_PRESSURE_500,
        [XmlEnum(Name = "P5000")]
        TRACE_PROBE_PRESSURE_5000,
        [XmlEnum(Name = "LA20")]
        TRACE_PROBE_LOW_AMPS_20,
        [XmlEnum(Name = "LA40")]
        TRACE_PROBE_LOW_AMPS_40,
        [XmlEnum(Name = "LA60")]
        TRACE_PROBE_LOW_AMPS_60,
        [XmlEnum(Name = "I")]
        TRACE_PROBE_IGNITION,
        [XmlEnum(Name = "O")]
        TRACE_PROBE_OHMS,
        [XmlEnum(Name = "D")]
        TRACE_PROBE_DIODE,
        [XmlEnum(Name = "DSA")]
        TRACE_PROBE_SHUNT,
        [XmlEnum(Name = "UD")]
        TRACE_PROBE_USER_DEFINED,
        [XmlEnum(Name = "CAP")]
        TRACE_PROBE_CAPACITANCE,
        [XmlEnum(Name = "EEDM506D_TEMP")]
        TRACE_PROBE_EEDM506D_TEMPERATURE,
        [XmlEnum(Name = "MT5030_P")]
        TRACE_PROBE_MT5030_PRESSURE,
        [XmlEnum(Name = "MT5030_V")]
        TRACE_PROBE_MT5030_VACUUM,
        [XmlEnum(Name = "HA200")]
        TRACE_PROBE_HIGH_AMPS_200,
        [XmlEnum(Name = "HA2000")]
        TRACE_PROBE_HIGH_AMPS_2000,
    }

}
