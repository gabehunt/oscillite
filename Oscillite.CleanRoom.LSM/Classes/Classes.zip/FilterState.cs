﻿using System.Xml.Serialization;

namespace Oscillite.CleanRoom.LSM
{
    public enum FilterState
    {
        [XmlEnum(Name = "On")]
        On,
        [XmlEnum(Name = "D")]
        Disabled,
        [XmlEnum(Name = "Off")]
        Off
    }
}
