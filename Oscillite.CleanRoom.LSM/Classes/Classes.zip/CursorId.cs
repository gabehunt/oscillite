using System;
using System.Xml.Serialization;

namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public class CursorId
	{
		private int cursorId;

		[XmlAttribute("V")]
		public int Value
		{
			get
			{
				return cursorId;
			}
			set
			{
				cursorId = value;
			}
		}
	}
}
