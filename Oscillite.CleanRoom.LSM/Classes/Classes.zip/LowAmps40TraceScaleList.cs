using System;

namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public class LowAmps40TraceScaleList : TraceScaleList
	{
		public LowAmps40TraceScaleList(float probeGain, float probeOffset)
			: base(TraceProbeType.TRACE_PROBE_LOW_AMPS_40, hasAutoScale: true)
		{
			Add(new TraceScale(10.0, TraceScale.Units.A, probeGain, probeOffset));
			Add(new TraceScale(20.0, TraceScale.Units.A, probeGain, probeOffset));
			Add(new TraceScale(40.0, TraceScale.Units.A, probeGain, probeOffset));
			Add(new TraceScale(60.0, TraceScale.Units.A, probeGain, probeOffset));
			base.SelectedScale = base[base.Count - 1];
		}
	}
}
