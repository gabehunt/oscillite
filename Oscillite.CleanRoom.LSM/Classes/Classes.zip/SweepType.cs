﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Oscillite.CleanRoom.LSM
{
    public enum SweepType
    {
        [XmlEnum(Name = "T")]
        Time,
        [XmlEnum(Name = "IP5ms")]
        Ignition_Parade_5ms,
        [XmlEnum(Name = "IP10ms")]
        Ignition_Parade_10ms,
        [XmlEnum(Name = "IC5ms")]
        Ignition_Cylinder_5ms,
        [XmlEnum(Name = "IC10ms")]
        Ignition_Cylinder_10ms,
        [XmlEnum(Name = "IR5ms")]
        Ignition_Raster_5ms,
        [XmlEnum(Name = "IR10ms")]
        Ignition_Raster_10ms,
        [XmlEnum(Name = "IS5ms")]
        Ignition_Superimposed_5ms,
        [XmlEnum(Name = "IS10ms")]
        Ignition_Superimposed_10ms
    }
}
