using System;
using System.Xml.Serialization;
using Oscillite.CleanRoom.LSM.Properties;


namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public class TraceId
	{
		private int id = 0;

		[XmlAttribute("V")]
		public int Value
		{
			get
			{
				return id;
			}
			set
			{
				id = value;
			}
		}

		public TraceId(int id)
		{
			this.id = id;
		}

		public TraceId(TraceId id)
		{
			this.id = id.id;
		}

		public override string ToString()
		{
			return $"TraceId: {id}";
		}

	}
}
