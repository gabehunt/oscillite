namespace Oscillite.CleanRoom.LSM
{
	public enum PressureUnits
	{
		psi,
		kPa,
		bar,
		kgcm2
	}
}
