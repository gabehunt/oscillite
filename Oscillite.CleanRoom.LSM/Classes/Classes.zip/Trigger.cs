using System;
using System.Xml.Serialization;

namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public class Trigger
	{
		private TriggerSource source;

		private TriggerMode mode;

		private TriggerLevel level;

		private TriggerDelay delay;

		private TriggerSlope slope;

		private TriggerCylinder cylinderNumber;

		private Trace associatedTrace;

        [XmlElement("Source")]
        public TriggerSource Source
        {
            get
            {
                return source;
            }
            set
            {
                source = new TriggerSource(value);
            }
        }

        [XmlElement("M")]
		public TriggerMode Mode
		{
			get
			{
				return mode;
			}
			set
			{
				mode = value;
			}
		}

		[XmlElement("L")]
		public TriggerLevel Level
		{
			get
			{
				return level;
			}
			set
			{
				level = value;
			}
		}

		[XmlElement("D")]
		public TriggerDelay Delay
		{
			get
			{
				return delay;
			}
			set
			{
				delay = value;
			}
		}

		[XmlElement("Sl")]
		public TriggerSlope Slope
		{
			get
			{
				return slope;
			}
			set
			{
				slope = value;
			}
		}

		[XmlElement("C")]
		public TriggerCylinder CylinderNumber
		{
			get
			{
				return cylinderNumber;
			}
			set
			{
				cylinderNumber = value;
			}
		}

		[XmlIgnore]
		public Trace AssociatedTrace
		{
			get
			{
				return associatedTrace;
			}
			set
			{
				associatedTrace = value;
			}
		}

		public Trigger(TriggerSource.SourceType sourceType = TriggerSource.SourceType.None)
		{
			source = new TriggerSource(sourceType);
			mode = ((sourceType == TriggerSource.SourceType.Cylinder) ? new TriggerMode(TriggerMode.TriggerModeType.Auto) : new TriggerMode(TriggerMode.TriggerModeType.Normal));
			level = new TriggerLevel(0.0);
			delay = new TriggerDelay(0.0);
			slope = new TriggerSlope(TriggerSlope.SlopeType.Up);
			cylinderNumber = new TriggerCylinder(1u);
			associatedTrace = null;
		}

		public Trigger(Trace trace)
		{
			source = new TriggerSource(trace);
			mode = new TriggerMode(TriggerMode.TriggerModeType.Auto);
			level = new TriggerLevel(0.0);
			delay = new TriggerDelay(0.0);
			slope = new TriggerSlope(TriggerSlope.SlopeType.Up);
			cylinderNumber = new TriggerCylinder(1u);
			associatedTrace = trace;
			trace.AssociatedTrigger = this;
		}

	}
}
