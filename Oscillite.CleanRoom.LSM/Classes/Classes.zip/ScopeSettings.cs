using System;
using System.Xml.Serialization;

namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public class ScopeSettings
	{
		private ScopeType scopeType;

		private SweepList sweeps;

		private Sweep sweep;

		private TraceList traces;

		private TraceProbeList probes;

		private TriggerList triggers;

		private CursorList cursors;

		private Ignition ignition;

		private ScopeHardwareType scopeHardwareType = ScopeHardwareType.ScopeHardwareType_Unknown;

		private PressureUnits pressureUnits = PressureUnits.psi;

		private VacuumUnits vacuumUnits = VacuumUnits.inHg;

		private TemperatureUnits temperatureUnits = TemperatureUnits.degF;

		[XmlElement("ScopeType")]
		public ScopeType ScopeType
		{
			get
			{
				return scopeType;
			}
			set
			{
				scopeType = value;
			}
		}

		[XmlArray("SweepList")]
		[XmlArrayItem("Sweep")]
		public SweepList Sweeps
		{
			get
			{
				return sweeps;
			}
			set
			{
				sweeps = value;
			}
		}

		[XmlElement("SelectedSweep")]
		public Sweep Sweep
		{
			get
			{
				return sweep;
			}
			set
			{
				sweep = sweeps[value.Name];
			}
		}

		[XmlArray("TraceList")]
		[XmlArrayItem("Trace")]
		public TraceList TraceList
		{
			get
			{
				return traces;
			}
			set
			{
				traces = value;
			}
		}

		[XmlArray("TraceProbeList")]
		[XmlArrayItem("TraceProbe")]
		public TraceProbeList Probes
		{
			get
			{
				return probes;
			}
			set
			{
				probes = value;
			}
		}

		[XmlArray("TriggerList")]
		[XmlArrayItem("Trigger")]
		public TriggerList TriggerList
		{
			get
			{
				return triggers;
			}
			set
			{
				triggers = value;
			}
		}

		[XmlElement("SelectedTrigger")]
		public Trigger SelectedTriggers
		{
			get
			{
				return triggers.SelectedTrigger;
			}
			set
			{
				triggers.SelectedTrigger = value;
			}
		}

		[XmlArray("CursorList")]
		[XmlArrayItem("Cursor")]
		public CursorList Cursors
		{
			get
			{
				return cursors;
			}
			set
			{
				cursors = value;
			}
		}

		[XmlElement("Ignition")]
		public Ignition Ignition
		{
			get
			{
				return ignition;
			}
			set
			{
				ignition = value;
			}
		}

		[XmlElement("PressureUnits")]
		public PressureUnits PressureUnits
		{
			get
			{
				return pressureUnits;
			}
			set
			{
				pressureUnits = value;
			}
		}

		[XmlElement("VacuumUnits")]
		public VacuumUnits VacuumUnits
		{
			get
			{
				return vacuumUnits;
			}
			set
			{
				vacuumUnits = value;
			}
		}

		[XmlElement("TemperatureUnits")]
		public TemperatureUnits TemperatureUnits
		{
			get
			{
				return temperatureUnits;
			}
			set
			{
				temperatureUnits = value;
			}
		}

		[XmlElement("ScopeHardwareType")]
		public ScopeHardwareType ScopeHardwareType
		{
			get
			{
				return scopeHardwareType;
			}
			set
			{
				scopeHardwareType = value;
			}
		}

		public ScopeSettings(ScopeType scopeType, TraceList.TraceCount traceCount, SweepList sweeps)
		{
			scopeHardwareType = ScopeHardwareType.ScopeHardwareType_Unknown;
			switch (scopeType)
			{
				case ScopeType.ScopeType_LabScope:
					{
						this.scopeType = scopeType;
						this.sweeps = sweeps;
						probes = new LabScopeTraceProbeList();
						traces = new TraceList(scopeType, traceCount, probes);
						sweep = this.sweeps.DefaultSweep;
						triggers = new TriggerList(traces);
						cursors = new CursorList();
						ignition = new Ignition();
						for (int l = 0; l < TraceList.Count; l++)
						{
							Trace trace4 = TraceList[l];
							trace4.Enabled.Value = l == 0;
							trace4.Inverted.Value = false;
							trace4.Scale = trace4.Probe.TraceScaleList[20.0];
							trace4.Position.Value = WaveformHelper.GetVerticalOffset(trace4, TraceList.Count, l);
						}
						break;
					}
				case ScopeType.ScopeType_GraphingMeter:
					{
						this.scopeType = scopeType;
						this.sweeps = sweeps;
						probes = new GraphingMeterTraceProbeList();
						traces = new TraceList(scopeType, traceCount, probes);
						sweep = this.sweeps.DefaultSweep;
						triggers = new TriggerList(new Trigger());
						cursors = new CursorList();
						ignition = new Ignition();
						for (int traceIndex = 0; traceIndex < TraceList.Count; traceIndex++)
						{
							Trace trace2 = TraceList[traceIndex];
							trace2.Enabled.Value = traceIndex == 0;
							trace2.Inverted.Value = false;
							trace2.Filter.Value = FilterState.On;
							trace2.PeakDetect.Value = IsDvomChannel(traceIndex) ? TracePeakDetect.PeakDetectStatus.Off : TracePeakDetect.PeakDetectStatus.On;
							trace2.Scale = trace2.Probe.TraceScaleList[20.0];
							trace2.Position.Value = WaveformHelper.GetVerticalOffset(trace2, TraceList.Count, traceIndex);
						}
						break;
					}
				case ScopeType.ScopeType_IgnitionScope:
					{
						this.scopeType = scopeType;
						this.sweeps = sweeps;
						probes = new IgnitionScopeTraceProbeList();
						traces = new TraceList(scopeType, traceCount, probes);
						sweep = this.sweeps.DefaultSweep;
						triggers = new TriggerList(traces);
						cursors = new CursorList();
						ignition = new Ignition();
						for (int k = 0; k < TraceList.Count; k++)
						{
							Trace trace3 = TraceList[k];
							trace3.Enabled.Value = k == 0;
							trace3.Inverted.Value = true;
							trace3.PeakDetect.Value = TracePeakDetect.PeakDetectStatus.On;
							trace3.Probe = Probes[TraceProbeType.TRACE_PROBE_IGNITION];
							trace3.Scale = trace3.Probe.TraceScaleList[20000.0];
							trace3.Position.Value = WaveformHelper.GetVerticalOffset(trace3, TraceList.Count, k);
						}
						if (ignition.IgnitionType == Ignition_Type.WasteSpark)
						{
							TracePosition tracePosition = new TracePosition();
							tracePosition = TraceList[0].Position;
							TraceList[0].Position = TraceList[1].Position;
							TraceList[1].Position = tracePosition;
							TraceList[1].Enabled.Value = true;
						}
						break;
					}
				case ScopeType.ScopeType_DigitalMeter:
					{
						this.scopeType = scopeType;
						this.sweeps = sweeps;
						probes = new DvomTraceProbeList();
						traces = new TraceList(scopeType, traceCount, probes);
						sweep = this.sweeps.DefaultSweep;
						triggers = new TriggerList(new Trigger());
						cursors = new CursorList();
						ignition = new Ignition();
						for (int i = 0; i < TraceList.Count; i++)
						{
							Trace trace = TraceList[i];
							trace.Enabled.Value = i == 0;
							trace.Inverted.Value = false;
							trace.Scale = trace.Probe.TraceScaleList[20.0];
							trace.Position.Value = WaveformHelper.GetVerticalOffset(trace, TraceList.Count, i);
						}
						break;
					}
				default:
					throw new Exception("Invalid Scope Type");
			}

			Sweep = Sweeps.DefaultSweep;
			int count = TraceList.Count;
			Sweeps.MaxNumberOfFilters = count;
			Sweeps.MaxNumberOfPeakDetects = count;
			
			for (int m = 0; m < Cursors.Count; m++)
			{
				Cursors[m].Position = new CursorPosition() { Value = Sweep.Seconds * (double)(m + 1) / (double)(Cursors.Count + 1) };
			}

			for (int n = 0; n < TriggerList.Count; n++)
			{
				Trigger trigger = TriggerList[n];
				if (this.scopeType == ScopeType.ScopeType_IgnitionScope && trigger.Source.IsCylinder())
				{
					trigger.Mode.Value = TriggerMode.TriggerModeType.Normal;
				}
				if (trigger.AssociatedTrace != null)
				{
					trigger.Level.Value = trigger.AssociatedTrace.Scale.FullScaleValue / 10.0;
				}
				else if (this.scopeType == ScopeType.ScopeType_IgnitionScope && trigger.Source.IsCylinder())
				{
					trigger.Level.Value = traces[new TraceId(1)].Scale.FullScaleValue / 10.0;
				}
				else
				{
					trigger.Level.Value = 0.0;
				}
				if (this.scopeType == ScopeType.ScopeType_IgnitionScope && trigger.Source.IsCylinder())
				{
					trigger.Delay.Value = 0.0;
				}
				else if (trigger.Source.Type == TriggerSource.SourceType.None)
				{
					trigger.Delay.Value = 0.0;
				}
				else
				{
					trigger.Delay.Value = Sweep.Seconds / 10.0;
				}
				trigger.Slope.Value = TriggerSlope.SlopeType.Down;
			}
			TriggerList.SelectedTrigger = TriggerList[0];
		}

        private static bool IsDvomChannel(int traceIndex)
        {
            return (traceIndex >= 2);
        }
    }
}
