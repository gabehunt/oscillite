﻿namespace Oscillite.CleanRoom.LSM
{
    public static class WaveformHelper
    {
        public static double GetVerticalOffset(Trace trace, int traceCount, int traceIndex)
        {
            double result = trace.Scale.FullScaleValue * 0.5;
            switch (traceCount)
            {
                case 4:
                    result = trace.Scale.FullScaleValue * 0.25 * (double)(traceIndex + 1.0);
                    break;
                case 2:
                    result = trace.Scale.FullScaleValue * (0.5 * (double)traceIndex + 0.1);
                    break;
                case 1:
                    result = trace.Scale.FullScaleValue * 0.125;
                    break;
            }
            return result;
        }
    }
}
