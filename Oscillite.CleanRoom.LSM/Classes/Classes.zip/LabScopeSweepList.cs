using System;

namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public class LabScopeSweepList : SweepList
	{
		public LabScopeSweepList()
		{
			Add(new Sweep() { Seconds =5E-05});
			Add(new Sweep() { Seconds =0.0001});
			Add(new Sweep() { Seconds =0.0002});
			Add(new Sweep() { Seconds =0.0005});
			Add(new Sweep() { Seconds =0.001});
			Add(new Sweep() { Seconds =0.002});
			Add(new Sweep() { Seconds =0.005});
			Add(new Sweep() { Seconds =0.01});
			Add(new Sweep() { Seconds =0.02});
			Add(new Sweep() { Seconds =0.05});
			Add(new Sweep() { Seconds =0.1});
			Add(new Sweep() { Seconds =0.2});
			Add(new Sweep() { Seconds =0.5});
			Add(new Sweep() { Seconds =1.0});
			Add(new Sweep() { Seconds =2.0});
			Add(new Sweep() { Seconds =5.0});
			Add(new Sweep() { Seconds =10.0});
			Add(new Sweep() { Seconds =20.0});
			if (base.DefaultSweep == null)
			{
				base.DefaultSweep = base[base.Count - 1];
			}
		}
	}
}
