using System;
using System.Collections.Generic;

namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public class TriggerList : List<Trigger>
	{
		private Trigger selectedTrigger = new Trigger();

		public Trigger SelectedTrigger
		{
			get
			{
				return selectedTrigger;
			}
			set
			{
				selectedTrigger = this[value.Source];
			}
		}

		public Trigger this[TriggerSource source]
		{
			get
			{
				using (Enumerator enumerator = GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						Trigger current = enumerator.Current;
						if (current.Source.Value == source.Value)
						{
							return current;
						}
					}
				}
				throw new Exception("Trigger source " + source.ToString() + " not in Triger list");
			}
		}

		public new Trigger this[int index]
		{
			get
			{
				return base[index];
			}
			set
			{
				base[index] = value;
			}
		}

		public TriggerList(Trigger trigger)
		{
			Add(trigger);
			selectedTrigger = this[base.Count - 1];
		}

		public TriggerList(TraceList traces)
		{
			selectedTrigger = null;
			for (int i = 0; i < traces.Count; i++)
			{
				Add(new Trigger(traces[i]));
			}
			Add(new Trigger(TriggerSource.SourceType.Cylinder));
			Add(new Trigger(TriggerSource.SourceType.None));
			selectedTrigger = this[base.Count - 1];
		}
	}
}
