using System;

namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public class Vacuum100inHgTraceScaleList : TraceScaleList
	{
		public Vacuum100inHgTraceScaleList(float probeGain, float probeOffset)
			: base(TraceProbeType.TRACE_PROBE_VACUUM_100, hasAutoScale: false)
		{
			Add(new TraceScale(5.0, TraceScale.Units.inHg, probeGain, probeOffset));
			Add(new TraceScale(10.0, TraceScale.Units.inHg, probeGain, probeOffset));
			Add(new TraceScale(20.0, TraceScale.Units.inHg, probeGain, probeOffset));
			Add(new TraceScale(30.0, TraceScale.Units.inHg, probeGain, probeOffset));
			base.SelectedScale = base[20.0];
		}
	}
}
