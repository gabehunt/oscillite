using System.Xml.Serialization;

namespace Oscillite.CleanRoom.LSM
{
	public enum ScopeHardwareType
	{
		ScopeHardwareType_ShopStreamConnect,
		[XmlEnum(Name = "LSPI")]
		ScopeHardwareType_LSPI,
		[XmlEnum(Name = "TPI_M2")]
		ScopeHardwareType_TPI_M2,
		[XmlEnum(Name = "No_HW")]
		ScopeHardwareType_NoHardware,
		[XmlEnum(Name = "Sim")]
		ScopeHardwareType_Simulator,
		[XmlEnum(Name = "Unk")]
		ScopeHardwareType_Unknown,
		[XmlEnum(Name = "M4")]
		ScopeHardwareType_M4,
		[XmlEnum(Name = "GM2")]
		ScopeHardwareType_GEP_2channel,
		[XmlEnum(Name = "M5")]
		ScopeHardwareType_M5,
		[XmlEnum(Name = "M6")]
		ScopeHardwareType_M6
	}
}
