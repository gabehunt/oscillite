using System;

namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public class BufferPosition : Position<uint>
	{
		public BufferPosition(uint position)
			: base(position)
		{
		}
	}
}
