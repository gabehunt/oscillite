using System;
using System.Xml.Serialization;

namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public class Trace
	{
		private TraceId id;

		private TraceEnabled enabled = new TraceEnabled();

		private TraceInverted inverted = new TraceInverted(inverted: false);

		private TraceCoupling coupling = new TraceCoupling();

		private TracePeakDetect peakDetect = new TracePeakDetect();

		private TraceFilter filter = new TraceFilter();

		private TraceProbe probe = new TraceProbe();

		private TraceScale scale = new TraceScale() { };

		private TracePosition position;

		private TraceRasterSpacing rasterSpacing;

		private Trigger associatedTrigger = null;

		private ThresholdSlope thresholdSlope;

		[XmlElement("Id")]
		public TraceId Id
		{
			get
			{
				return id;
			}
			set
			{
				id = value;
			}
		}

		[XmlElement("E")]
		public TraceEnabled Enabled
		{
			get
			{
				return enabled;
			}
			set
			{
				enabled = value;
			}
		}

		[XmlElement("I")]
		public TraceInverted Inverted
		{
			get
			{
				return inverted;
			}
			set
			{
				inverted = value;
			}
		}

		[XmlElement("C")]
		public TraceCoupling Coupling
		{
			get
			{
				return coupling;
			}
			set
			{
				coupling = value;
			}
		}

		[XmlElement("PD")]
		public TracePeakDetect PeakDetect
		{
			get
			{
				return peakDetect;
			}
			set
			{
				peakDetect = value;
			}
		}

		[XmlElement("F")]
		public TraceFilter Filter
		{
			get
			{
				return filter;
			}
			set
			{
				filter = value;
			}
		}

		[XmlElement("Pr")]
		public TraceProbe Probe
		{
			get
			{
				return probe;
			}
			set
			{
				probe = value;
			}
		}

		[XmlElement("S")]
		public TraceScale Scale
		{
			get
			{
				return scale;
			}
			set
			{
				scale = value;
			}
		}

		[XmlElement("P")]
		public TracePosition Position
		{
			get
			{
				return position;
			}
			set
			{
				position = value;
			}
		}

		[XmlElement("RS")]
		public TraceRasterSpacing RasterSpacing
		{
			get
			{
				return rasterSpacing;
			}
			set
			{
				rasterSpacing = value;
			}
		}

		[XmlIgnore]
		public Trigger AssociatedTrigger
		{
			get
			{
				return associatedTrigger;
			}
			set
			{
				associatedTrigger = value;
			}
		}

		[XmlElement("TS")]
		public ThresholdSlope ThresholdSlope
		{
			get
			{
				return thresholdSlope;
			}
			set
			{
				thresholdSlope = value;
			}
		}
	}
}
