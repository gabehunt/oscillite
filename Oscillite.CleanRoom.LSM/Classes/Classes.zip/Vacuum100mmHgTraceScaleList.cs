using System;

namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public class Vacuum100mmHgTraceScaleList : TraceScaleList
	{
		public Vacuum100mmHgTraceScaleList(float probeGain, float probeOffset)
			: base(TraceProbeType.TRACE_PROBE_VACUUM_100, hasAutoScale: false)
		{
			Add(new TraceScale(100.0, TraceScale.Units.mmHg, probeGain, probeOffset));
			Add(new TraceScale(200.0, TraceScale.Units.mmHg, probeGain, probeOffset));
			Add(new TraceScale(500.0, TraceScale.Units.mmHg, probeGain, probeOffset));
			base.SelectedScale = base[500.0];
		}
	}
}
