using System;
using System.Xml.Serialization;

namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public class TraceCoupling
	{
		public enum TraceCouplingType
		{
			[XmlEnum(Name = "CAC")]
			Coupling_AC,
			[XmlEnum(Name = "CDC")]
			Coupling_DC
		}

		private TraceCouplingType coupling = TraceCouplingType.Coupling_DC;

		[XmlAttribute("V")]
		public TraceCouplingType Value
		{
			get
			{
				return coupling;
			}
			set
			{
				coupling = value;
			}
		}
	}
}
