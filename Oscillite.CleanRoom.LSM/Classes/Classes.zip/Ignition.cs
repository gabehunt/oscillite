using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace Oscillite.CleanRoom.LSM
{
	[Serializable]
	public class Ignition
	{
        private string firingOrder = "1 2 3 4";

        private Ignition_Type ignitionType = Ignition_Type.Conventional;

        private uint numberOfCylinders = 4u;

		private string polarity = "+ - + -";

        private Cycles engineStroke = Cycles.Four;

		[XmlAttribute("IT")]
		public Ignition_Type IgnitionType
		{
			get
			{
				return ignitionType;
			}
			set
			{
				ignitionType = value;
			}
		}

		[XmlAttribute("NOC")]
		public uint NumberOfCylinders
		{
			get
			{
				return numberOfCylinders;
			}
			set
			{
					numberOfCylinders = value;
			}
		}

		[XmlAttribute("FO")]
		public string FiringOrder
		{
			get
			{
				return firingOrder;
			}
			set
			{
                firingOrder = value;
			}
		}

		[XmlAttribute("P")]
		public string Polarity
		{
			get
			{
				return polarity;
			}
			set
			{
                polarity = value;
			}
		}

		[XmlAttribute("ES")]
		public Cycles EngineStroke
		{
			get
			{
				return engineStroke;
			}
			set
			{
				engineStroke = value;
			}
		}
	}
}
